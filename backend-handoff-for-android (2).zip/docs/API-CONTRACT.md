# قرارداد API بک‌اند گیمیفای (`https://bu.gamifi.ir`)

> استخراج‌شده از کد مرجع `src/app/api/**/route.ts`، `src/lib/auth.ts`، `src/db/schema.ts` و migrations.
> این سند مبنای پیاده‌سازی اپ اندروید است. هیچ مسیری که در کد وجود ندارد فرض نشده است.

## ۱) احراز هویت و نشست

| مورد | مقدار |
|---|---|
| جدول نشست | `sessions(token PK, user_id, csrf, expires[ms])` — اعتبار ۳۰ روز |
| ارسال توکن از اپ | هدر `x-gamify-token: <token>` **یا** `Authorization: Bearer <token>` (کوکی `gtok`/`gm_session` فقط برای مرورگر) |
| دریافت توکن | فیلد `serverToken` در پاسخ `POST /api/auth/guest`، `POST /api/account {action:"login"}`، `POST /api/daily` و هدر پاسخ `x-gamify-token` |
| خطای بدون نشست | `401 {error:"not-authed"}` |
| SSE | `GET /api/events?token=<token>` (EventSource هدر نمی‌فرستد؛ توکن در query) |

### چرخهٔ ورود در اپ (عین `session-client.ts`)
1. `GET /api/me` با توکن ذخیره‌شده → اگر `200` پروفایل است.
2. اگر `401` → `POST /api/auth/guest {name?, avatar?, org?}` → پروفایل + `serverToken` → ذخیره در دستگاه.
3. خطای ۵۰۰/شبکه **نباید** پروفایل جعلی بسازد (فقط پیام خطا).

### ورود با نام‌کاربری/رمز
`POST /api/account` بدنه `{action:"login", identifier, password}` → `{ok:true, serverToken}` یا `401 {error:"نام کاربری یا رمز درست نیست…"}` (قفل ۱۵ دقیقه بعد از ۵ خطا).

### تبدیل میهمان به حساب دائمی
`POST /api/account` بدنه `{action:"save", username, password, name?, email?, phone?, currentPassword?}` → `{ok:true, reward}` (۵۰ سکه پاداش اولین ثبت تماس). `GET /api/account?username=x` → `{available:boolean}`. `GET /api/account` → `{user, identifiers[], hasPassword, pushEnabled}`.
سایر اکشن‌ها: `logout` (حذف نشست)، `push {enabled}`.

## ۲) شکل عمومی کاربر (`pub(u)`)
```
{ id, name, avatar:{img:1..20}|{bg,skin,outfit,hair,hairColor,eyes}, bio, role:"player"|"admin", email, phone, provider,
  orgId, xp, coins, cups, streak, wins, played, rating, weekXp, level, interests[], interestsSet, friends[], private,
  isDemo, isReal, lastSeen, createdAt }
```
تصویر آواتار: `https://bu.gamifi.ir/assets/avatars/NN.png` (دو رقمی). سطح = `floor(xp/250)+1`.

## ۳) فهرست کامل مسیرها

| مسیر | متد | ورودی | خروجی | نیاز به نشست |
|---|---|---|---|---|
| `/api/health` | GET | — | `{ok}` | ✗ |
| `/api/me` | GET | — | کاربر | ✓ |
| `/api/me` | POST | `{name?,avatar?,bio?,interests?,xp?,coins?…}` | کاربر به‌روز | ✓ |
| `/api/auth/guest` | POST | `{name?,avatar?,interests?,org?}` | کاربر + `serverToken` | ✗ |
| `/api/account` | GET/POST | بالا | بالا | بسته به اکشن |
| `/api/site-config` | GET | — | `{settings, textOverrides, assetOverrides, broadcasts[], categories[], serverNow}` | ✗ |
| `/api/questions?category=_categories` | GET | — | `[{id,name,subtitle,icon,color,tag,safety,active,questionCount}]` | ✗ |
| `/api/questions?category=X&count=5` | GET | 1..10 | سؤال بدون پاسخ (برای نبرد قبیله) | ✗ |
| `/api/matches` | GET | `?id=` یا هیچ (مسابقهٔ فعال) | `{match}` | ✓ |
| `/api/matches?standings=ID` | GET | — | `{title, final, endsAt, rank, total, leaders[]}` | ✓ |
| `/api/matches` | POST | `{action:"start", mode, category?, competitionId?}` | `visible(match)` (۲۰۱) | ✓ |
| `/api/matches` | POST | `{action:"answer", id, round, choice:-1..3}` | `visible(match)` | ✓ |
| `/api/matches` | POST | `{action:"next", id, round}` | `visible(match)` | ✓ |
| `/api/matches` | POST | `{action:"help", id, round, kind:"fifty"|"hint"|"time"}` | `visible(match)` | ✓ |
| `/api/matches` | POST | `{action:"forfeit", id}` | `visible(match)` | ✓ |
| `/api/daily` | GET | `?kind=daily|notifications|achievements` | `{claimed,streak,coins}` / `[]` | ✓ |
| `/api/daily` | POST | `{}` | `{ok,coins,balance,streak,message,serverToken}` یا `400` | ✓ |
| `/api/coins` | GET | — | `{coins,streak,lastDaily,claimedToday}` | ✓ |
| `/api/coins` | POST | `{op:"buy", itemId}` / `{op:"delta", delta}` | `{ok, coins, …}` | ✓ |
| `/api/leaderboard?scope=players|week|tribes` | GET | — | `[{rank,…}]` | ✗ |
| `/api/players?online=1&real=1&limit=` | GET | — | `[{…pub, online, isBot}]` | ✗ |
| `/api/arena` | GET | — | `{me, level:{level,xp,into,need}, rank, wheel:{canSpin,prizes[],lastPrize}, quests[], hall[], tribes[]}` | ✓ |
| `/api/arena?action=spin` | POST | `{}` | `{ok,index,prize:{label,icon,coins,xp}}` | ✓ |
| `/api/arena?action=claim` | POST | `{id}` | `{ok,coins,xp}` | ✓ |
| `/api/competitions?kind=league|event` | GET | — | `{items:[{id,title,category,org_id,starts_at,ends_at,question_count,seconds}],categories,admin,serverNow}` | ✓ |
| `/api/leagues` | GET | — | `[{id,title,category,orgId,startsAt,endsAt,questionCount,seconds,open}]` | ✗ |
| `/api/tournaments` | GET | — | `[{id,title,category,startsAt,endsAt,open,orgLocked,joined,myScore,questionCount}]` | ✗ |
| `/api/tournaments?action=join` | POST | `{id}` | `{ok}` | ✓ |
| `/api/pvp?action=inbox` | GET | — | `{me,serverNow,incoming[],outgoing[],active[],results[]}` | ✓ |
| `/api/pvp?action=state&id=` | GET | — | وضعیت کامل نبرد (`questions[]` فقط پنجرهٔ بازشده، `reveal[]`, `result`) | ✓ |
| `/api/pvp?action=history` | GET | — | `[{id,at,category,me,opp,won,draw}]` | ✓ |
| `/api/pvp?action=invite` | POST | `{to, category, rematchOf?}` | `{ok, battle}` | ✓ |
| `/api/pvp?action=accept|decline|cancel|forfeit|ack` | POST | `{id}` | `{ok, battle?}` | ✓ |
| `/api/pvp?action=answer` | POST | `{id, q, i}` | `{ok, correct, late, finished}` | ✓ |
| `/api/pvp?action=rematch` | POST | `{id}` | `{ok,battle}` | ✓ |
| `/api/tribes` | GET | `?q=` / `?mine=1` | `[tribe]` / `{tribe, members[]}` | mine ✓ |
| `/api/tribes` | POST | `{name,tag,description,motto,logoEmoji,logoColor,isPublic}` | `{ok,id,…}` | ✓ |
| `/api/tribes/:id` | GET | `?action=detail|members|battles` | — | ✗ |
| `/api/tribes/:id?action=join|leave|invite|challenge|battle-answer|update` | POST | `{code?,name?,enemyId?…}` | `{ok,message}` | ✓ |
| `/api/stories` | GET | `?view=more&offset=` | `{serverNow,hasMore,stories[]}` | ✓ |
| `/api/stories` | POST | `{id, answer?}` | `{ok, correct?, explanation?}` | ✓ |
| `/api/feed` | GET | `?type=posts|stories&since=` | `[post]` | ✗ |
| `/api/feed?type=post|story` | POST | `{body,category,media?}` / `{title,options,correct,explanation}` | `{ok,id,status}` | ✓ |
| `/api/messages?scan=1` | GET | — | `[{id,name,avatar,lastAt,lastText,unread,online}]` | ✓ |
| `/api/messages?with=ID` | GET | — | `[{id,from_id,to_id,text,at,read,from:"me"|"them"}]` | ✓ |
| `/api/messages` | POST | `{to, text}` | `{id, at}` | ✓ |
| `/api/orgs` | GET | — | سازمان‌ها | ✗ |
| `/api/events?token=` | GET (SSE) | — | رویدادهای `pvp:*`, `chat:message`, `feed:*`, `ping` | ✓ |
| `/api/push/*` | — | Web-Push (VAPID) — فقط مرورگر | — |

## ۴) منطق مسابقهٔ سرور (`quiz-rules.ts`) — باید در اپ تکرار شود
- حالت‌ها: `ranked, computer, friendly, practice, daily, event, league`؛ `practice/daily` بدون حریف، بقیه حریف ربات با دقت `botAccuracy`.
- هر دور: `roundAt` (۱.۵ ثانیه پس از شروع/next) و `deadline = roundAt + (seconds+bonus)*1000`؛ تایمر از `serverNow` تنظیم شود نه ساعت دستگاه.
- امتیاز پاسخ صحیح: `100 + تا ۵۰ امتیاز سرعت + تا ۳۰ امتیاز زنجیره`.
- کمک‌ها: `fifty` (دو گزینهٔ غلط حذف → `usedHelps.fifty:[i,j]`)، `hint` (متن راهنما)، `time` (+۱۰ ثانیه).
- پاداش پایان: `xp = صحیح×10 (+30 برد)`, `coins = صحیح×2 (+20 برد, +25 روزانه)`, `cups = برد؟1:0`.
- نبرد زنده PvP: ۵ سؤال × ۱۵ ثانیه + ۲.۵ ثانیه فاصله؛ `startedAt` از سرور؛ پاسخ با `{q,i}`.

## ۵) کمبودها و نکات (مستندسازی شکاف‌ها)
1. **CORS ندارد** → اپ بومی باید یا از طریق پروکسی هم‌مبدأ (این پروژه: `/api/gw/*`) یا با `CapacitorHttp` (درخواست بومی، بدون CORS) بک‌اند را صدا بزند. در این پروژه هر دو پشتیبانی می‌شود.
2. **Push اندروید وجود ندارد** — فقط Web-Push (VAPID). برای FCM باید بعداً endpoint اضافه شود؛ اپ فعلاً اعلان‌ها را از `GET /api/daily?kind=notifications` می‌خواند.
3. **خروج (logout)** فقط کوکی را پاک می‌کند و توکن DB را حذف می‌کند؛ اپ باید توکن محلی را هم پاک کند.
4. `/api/daily` با هر دریافت پاداش توکن **جدید** می‌سازد (`serverToken`)؛ اپ باید آن را جایگزین کند.
5. هیچ endpoint «ثبت‌نام با ایمیل/OTP» وجود ندارد؛ فقط میهمان → ارتقا با نام‌کاربری/رمز.
6. آواتار سفارشی (آپلود) وجود ندارد؛ فقط ۲۰ تصویر یا پروفایل SVG.
7. فروشگاه: قیمت‌ها در سرور ثابت‌اند (`title-mentor:300, title-safety:250, extra-life:120, frame-gold:400, theme-night:200, badge-fire:150`).
8. `/api/stories` بدون نشست `401` می‌دهد؛ `/api/feed?type=stories` نسخهٔ عمومی است.
