#!/usr/bin/env bash
# 🌐 ساخت خروجی استاتیک رابط کاربری برای APK (مسیرهای API سرور کنار گذاشته می‌شوند؛ اپ مستقیم با bu.gamifi.ir کار می‌کند)
set -euo pipefail
cd "$(dirname "$0")/.."
export APK_BUILD=1
export NEXT_PUBLIC_API_BASE="${NEXT_PUBLIC_API_BASE:-https://bu.gamifi.ir/api}"
export NEXT_PUBLIC_ASSET_BASE="${NEXT_PUBLIC_ASSET_BASE:-https://bu.gamifi.ir}"
rm -rf out .next-apk
mv src/app/api /tmp/_gamifi_api_backup
trap 'mv /tmp/_gamifi_api_backup src/app/api' EXIT
npx next build
echo "✅ out/ آماده شد (API_BASE=$NEXT_PUBLIC_API_BASE)"
