#!/usr/bin/env bash
# 🔐 ساخت کلید امضای آپلود پلی‌استور برای ir.gamifi.bu
# نیاز: JDK 17 (keytool). خروجی: android/keystore/gamifi-upload.jks + android/keystore.properties
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p android/keystore
KS=android/keystore/gamifi-upload.jks
ALIAS=gamifi-upload
if [ -f "$KS" ]; then echo "کلید از قبل وجود دارد: $KS"; exit 0; fi
read -rsp "رمز کلید (حداقل ۸ نویسه، آن را در جای امن نگه دارید): " PASS; echo
keytool -genkeypair -v -keystore "$KS" -alias "$ALIAS" -keyalg RSA -keysize 4096 -validity 10000 \
  -storepass "$PASS" -keypass "$PASS" \
  -dname "CN=Gamifi Bushehr, OU=Mobile, O=Behinesaz Bargh Bushehr, L=Bushehr, ST=Bushehr, C=IR"
cat > android/keystore.properties <<PROPS
storeFile=keystore/gamifi-upload.jks
storePassword=$PASS
keyAlias=$ALIAS
keyPassword=$PASS
PROPS
echo
echo "✅ کلید ساخته شد: $KS"
echo "اثر انگشت SHA-256 (برای Play Console / App Links):"
keytool -list -v -keystore "$KS" -alias "$ALIAS" -storepass "$PASS" | grep -E "SHA1|SHA256"
echo
echo "⚠️  فایل .jks و keystore.properties را هرگز commit نکنید (در .gitignore هستند)."
