#!/usr/bin/env bash
# 🏗️ ساخت APK و AAB امضاشده (نیاز: JDK 17، Android SDK، android/keystore.properties)
set -euo pipefail
cd "$(dirname "$0")/.."
./android-scripts/build-web.sh
npx cap sync android
cd android && ./gradlew --no-daemon assembleRelease bundleRelease
cd ..
mkdir -p release
cp android/app/build/outputs/apk/release/app-release.apk release/gamifi-2-release.apk
cp android/app/build/outputs/bundle/release/app-release.aab release/gamifi-2-release.aab
echo "✅ release/gamifi-2-release.apk  و  release/gamifi-2-release.aab"
