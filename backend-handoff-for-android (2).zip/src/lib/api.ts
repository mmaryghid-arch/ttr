"use client";
/**
 * لایهٔ ارتباط با بک‌اند گیمیفای — همان قرارداد session-client.ts نسخهٔ وب
 * توکن نشست در دستگاه ذخیره می‌شود و با هدر `x-gamify-token` ارسال می‌گردد.
 */
const TOKEN_KEY = "gm_token";
/** در APK: NEXT_PUBLIC_API_BASE=https://bu.gamifi.ir/api (مستقیم، از طریق CapacitorHttp بومی) — در وب: /api/gw */
export const BASE = (process.env.NEXT_PUBLIC_API_BASE || "/api/gw").replace(/\/$/, "");
export const DIRECT = /^https?:/i.test(BASE);

export class ApiError extends Error { status: number; data: unknown; constructor(status: number, data: unknown) { super(typeof (data as { error?: string })?.error === "string" ? (data as { error: string }).error : `http-${status}`); this.status = status; this.data = data; } }

export const token = {
  get: () => (typeof window === "undefined" ? "" : localStorage.getItem(TOKEN_KEY) || ""),
  set: (t: string) => { if (typeof window !== "undefined") { if (t) localStorage.setItem(TOKEN_KEY, t); else localStorage.removeItem(TOKEN_KEY); } },
};

let mockFlag = false;
export const isMock = () => mockFlag;
const listeners = new Set<() => void>();
export const onMock = (fn: () => void) => { listeners.add(fn); return () => { listeners.delete(fn); }; };

export async function api<T = unknown>(path: string, init: { method?: string; body?: unknown; silent?: boolean } = {}): Promise<T> {
  const headers: Record<string, string> = { accept: "application/json" };
  const t = token.get(); if (t) headers["x-gamify-token"] = t;
  if (init.body !== undefined) headers["content-type"] = "application/json";
  const res = await fetch(`${BASE}/${path.replace(/^\//, "")}`, { method: init.method || (init.body !== undefined ? "POST" : "GET"), headers, body: init.body !== undefined ? JSON.stringify(init.body) : undefined, cache: "no-store" });
  const fresh = res.headers.get("x-gamify-token"); if (fresh && fresh !== t) token.set(fresh);
  if (res.headers.get("x-gamifi-mock") && !mockFlag) { mockFlag = true; listeners.forEach((fn) => fn()); }
  let data: unknown = null; const text = await res.text(); try { data = text ? JSON.parse(text) : null; } catch { data = { error: text.slice(0, 200) }; }
  if (data && typeof data === "object" && typeof (data as { serverToken?: string }).serverToken === "string") token.set((data as { serverToken: string }).serverToken);
  if (!res.ok) throw new ApiError(res.status, data);
  return data as T;
}

export const get = <T,>(p: string) => api<T>(p);
export const post = <T,>(p: string, body: unknown = {}) => api<T>(p, { method: "POST", body });

/** چرخهٔ نشست: /api/me → اگر 401 → /api/auth/guest. خطای شبکه/۵۰۰ پروفایل جعلی نمی‌سازد. */
export async function ensureSession(): Promise<User> {
  try { return await get<User>("me"); }
  catch (e) { if (e instanceof ApiError && e.status === 401) { token.set(""); return await post<User>("auth/guest", {}); } throw e; }
}

export const ASSET = (process.env.NEXT_PUBLIC_ASSET_BASE || "https://bu.gamifi.ir").replace(/\/$/, "");

/** رویداد زنده: در وب SSE هم‌مبدأ؛ در اپ بومی EventSource از CapacitorHttp عبور نمی‌کند (CORS) → فقط polling. */
export function subscribe(events: string[], fn: () => void): () => void {
  if (DIRECT || typeof window === "undefined" || typeof EventSource === "undefined") return () => {};
  try { const es = new EventSource(`${BASE}/events?token=${encodeURIComponent(token.get())}`); events.forEach((e) => es.addEventListener(e, fn)); return () => es.close(); } catch { return () => {}; }
}
export function avatarUrl(a: unknown, name = ""): string {
  let img = 0;
  if (typeof a === "number") img = a; else if (a && typeof a === "object") img = Number((a as { img?: number }).img) || 0;
  if (img < 1 || img > 20) { let h = 0; for (let i = 0; i < name.length; i++) h = (h * 31 + name.charCodeAt(i)) >>> 0; const list = [1, 3, 5, 7, 8, 10, 11, 12, 13, 14, 17, 19, 20]; img = list[h % list.length]; }
  return `${ASSET}/assets/avatars/${String(img).padStart(2, "0")}.png`;
}
export const catIcon = (id: string) => `${ASSET}/assets/categories/${id}.svg`;
export const fa = (n: number | string | null | undefined) => Number(n || 0).toLocaleString("fa-IR");
export const levelOf = (xp: number) => Math.floor((xp || 0) / 250) + 1;
export function ago(t: number) { const d = Math.max(0, Date.now() - t); const m = Math.floor(d / 60000); if (m < 1) return "همین حالا"; if (m < 60) return `${fa(m)} دقیقه پیش`; const h = Math.floor(m / 60); if (h < 24) return `${fa(h)} ساعت پیش`; return `${fa(Math.floor(h / 24))} روز پیش`; }
export function left(ms: number) { if (ms <= 0) return "پایان یافته"; const h = Math.floor(ms / 3600000), d = Math.floor(h / 24); if (d >= 1) return `${fa(d)} روز و ${fa(h % 24)} ساعت`; const m = Math.floor((ms % 3600000) / 60000); return `${fa(h)} ساعت و ${fa(m)} دقیقه`; }

// ---------- انواع (استخراج از pub() و route ها) ----------
export type User = { id: string; name: string; avatar: unknown; bio: string; role: string; email: string; phone: string; provider: string; orgId: string; xp: number; coins: number; cups: number; streak: number; wins: number; played: number; rating: number; weekXp: number; level: number; interests: string[]; friends: string[]; isDemo: boolean; lastSeen: number; createdAt: number; serverToken?: string };
export type Category = { id: string; name: string; subtitle: string; icon: string; color: string; tag: string; safety: number; active: number; questionCount?: number };
export type SiteConfig = { settings: Record<string, unknown>; broadcasts: { id: string; title: string; body: string; image: string; link: string; at: number }[]; categories: Category[]; serverNow: number };
export type MatchAnswer = { round: number; choice: number; correct: boolean; points: number; elapsed: number; rivalPoints: number };
export type Match = { id: string; category: string; mode: string; status: string; competitionId: string; round: number; total: number; seconds: number; roundAt: number; deadline: number; serverNow: number; score: number; rivalScore: number; rival: { id: string; name: string; avatar: unknown } | null; helps: Record<string, number>; usedHelps: { fifty?: number[]; hint?: string; time?: boolean }; reward: { xp: number; coins: number; cups: number } | null; answers: MatchAnswer[]; question: { id: string; title: string; options: string[]; media: string; correct?: number; explanation?: string } | null };
export type Player = User & { online: boolean; isBot: boolean; rank?: number };
export type Competition = { id: string; title: string; category: string; org_id: string; starts_at: number; ends_at: number; question_count: number; seconds: number };
export type PvpMini = { id: string; category: string; status: string; at: number; opponent: { id: string; name: string; avatar: unknown; xp: number; wins: number; online: boolean; isBot: boolean }; iAmA: boolean; myDone: boolean; oppDone: boolean; seen: boolean; myScore: number | null; oppScore: number | null; winnerId: string; finishedAt: number; expiresAt: number };
export type PvpState = PvpMini & { me: string; qCount: number; serverNow: number; startedAt: number; seconds: number; gap: number; deadline: number; questions?: ({ id: string; title: string; options: string[]; seconds: number } | null)[]; myAnswered?: boolean[]; oppAnswered?: boolean[]; reveal?: ({ correct: number; myPick: number; oppPick: number } | null)[]; result?: { winnerId: string; myScore: number; oppScore: number; myCorrect: number; oppCorrect: number; myMs: number; oppMs: number; perQ: { title: string; options: string[]; correct: number; explanation: string; myPick: number; oppPick: number }[] } };
export type Tribe = { id: string; name: string; tag: string; description: string; motto: string; logoEmoji: string; logoColor: string; ownerId: string; maxMembers: number; wins: number; losses: number; xp: number; rating: number; isPublic: boolean; memberCount: number; isMember?: boolean; myRole?: string | null; rank?: number };
export type TribeMember = { id: string; name: string; avatar: unknown; xp: number; level: number; role: string; contributedXp: number; online: boolean };
export type Story = { id: string; userId: string; author: string; avatar: unknown; title: string; media: string; options: string[]; createdAt: number; expiresAt: number; seen: boolean };
export type Post = { id: string; userId: string; userName: string; category: string; body: string; media: string; likes: number; createdAt: number };
export type Contact = { id: string; name?: string; avatar?: unknown; lastAt: number; lastText: string; unread: number; online?: boolean };
export type Message = { id: string; from_id: string; to_id: string; text: string; at: number; read: number; from: "me" | "them" };
export type Arena = { me: User; level: { level: number; xp: number; into: number; need: number }; rank: number; wheel: { canSpin: boolean; prizes: { label: string; icon: string }[]; lastPrize: string }; quests: { id: string; icon: string; title: string; target: number; progress: number; coins: number; xp: number; ready: boolean; claimed: boolean }[]; hall: { rank: number; id: string; name: string; avatar: unknown; weekXp: number; xp: number }[]; tribes: { id: string; name: string; emoji: string; xp: number }[] };
