"use client";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Btn, Card, Chip, PageHeader, Skeleton, useToast } from "@/components/ui";
import { get, post, catIcon, fa, type Category, type Match } from "@/lib/api";

const MODES = [
  { id: "ranked", title: "رتبه‌بندی", sub: "۷ سؤال · حریف · امتیاز رسمی", icon: "crown", color: "#f2ca7c" },
  { id: "computer", title: "نبرد با ربات", sub: "۷ سؤال · حریف هوشمند", icon: "cpu", color: "#b495f0" },
  { id: "practice", title: "تمرین آزاد", sub: "۷ سؤال · بدون حریف", icon: "target", color: "#8dd6b5" },
  { id: "daily", title: "چالش روزانه", sub: "۵ سؤال · روزی یک‌بار · +۲۵ سکه", icon: "fire", color: "#ffb37a" },
];

function PlayInner() {
  const r = useRouter(); const sp = useSearchParams(); const toast = useToast();
  const [cats, setCats] = useState<Category[] | null>(null);
  const [cat, setCat] = useState(sp.get("category") || "");
  const [mode, setMode] = useState("ranked");
  const [active, setActive] = useState<Match | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    get<Category[]>("questions?category=_categories").then((c) => { setCats(c); if (!cat && c[0]) setCat(c[0].id); }).catch(() => setCats([]));
    get<{ match: Match | null }>("matches").then((d) => setActive(d.match)).catch(() => {});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const start = async () => {
    setBusy(true);
    try { const m = await post<Match>("matches", { action: "start", mode, category: cat }); r.push(`/play/match?id=${m.id}`); }
    catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); }
    finally { setBusy(false); }
  };
  const forfeit = async () => { if (!active) return; try { await post("matches", { action: "forfeit", id: active.id }); setActive(null); toast("مسابقهٔ ناتمام بسته شد"); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } };

  return (
    <div>
      <PageHeader title="شروع بازی" sub="حالت و دسته را انتخاب کن" />
      <div className="px-4 space-y-5">
        {active ? (
          <Card className="border-[var(--gold)]/50 flex items-center gap-3 anim-pop">
            <span className="w-11 h-11 rounded-2xl logo-tile grid place-items-center text-[#2a1d12] anim-pulse"><Icon name="play" size={22} /></span>
            <div className="flex-1 min-w-0"><b className="block text-[14px]">یک مسابقهٔ ناتمام داری</b><span className="text-[12px] text-[var(--muted)]">سؤال {fa(active.round + 1)} از {fa(active.total)} · امتیاز {fa(active.score)}</span></div>
            <Btn size="sm" onClick={() => r.push(`/play/match?id=${active.id}`)}>ادامه</Btn>
            <Btn size="sm" variant="ghost" onClick={forfeit}>انصراف</Btn>
          </Card>
        ) : null}

        <section>
          <h2 className="font-black text-[15px] mb-2">حالت بازی</h2>
          <div className="grid grid-cols-2 gap-3 stagger">
            {MODES.map((m) => (
              <Card key={m.id} className={`!p-4 relative overflow-hidden transition-all ${mode === m.id ? "ring-2" : ""}`} onClick={() => setMode(m.id)} glow={mode === m.id ? m.color : undefined}>
                <style>{mode === m.id ? `.ring-2{--tw-ring-color:${m.color}}` : ""}</style>
                <span className="w-11 h-11 rounded-2xl grid place-items-center" style={{ background: `color-mix(in srgb, ${m.color} 20%, transparent)`, color: m.color }}><Icon name={m.icon} size={24} /></span>
                <b className="block mt-3 text-[14px]">{m.title}</b>
                <span className="text-[11px] text-[var(--muted)] leading-5 block">{m.sub}</span>
                {mode === m.id ? <span className="absolute top-3 left-3 w-6 h-6 rounded-full grid place-items-center text-[#2a1d12]" style={{ background: m.color }}><Icon name="check" size={14} strokeWidth={3} /></span> : null}
              </Card>
            ))}
          </div>
        </section>

        <section className={mode === "daily" ? "opacity-40 pointer-events-none" : ""}>
          <h2 className="font-black text-[15px] mb-2">دسته‌بندی {mode === "daily" ? "(روزانه توسط مدیر تعیین می‌شود)" : ""}</h2>
          <div className="space-y-2 stagger">
            {cats === null ? [1, 2, 3].map((i) => <Skeleton key={i} className="h-[72px]" />) : cats.filter((c) => c.active !== 0).map((c) => (
              <button key={c.id} onClick={() => setCat(c.id)} className={`press w-full flex items-center gap-3 p-3 rounded-2xl border text-right transition-all ${cat === c.id ? "bg-[#ffffff10]" : "bg-[var(--panel)] border-[var(--line)]"}`} style={cat === c.id ? { borderColor: c.color } : undefined}>
                <span className="w-12 h-12 rounded-xl grid place-items-center shrink-0" style={{ background: `color-mix(in srgb, ${c.color} 18%, transparent)` }}>
                  {/* eslint-disable-next-line @next/next/no-img-element */}
                  <img src={catIcon(c.id)} alt="" className="w-8 h-8" onError={(e) => ((e.target as HTMLImageElement).style.display = "none")} />
                </span>
                <span className="flex-1 min-w-0"><b className="block text-[14px]">{c.name}</b><span className="text-[11px] text-[var(--muted)] block truncate">{c.subtitle}</span></span>
                <span className="flex flex-col items-end gap-1">{c.tag ? <Chip color={c.color} className="!h-6 !text-[10px]">{c.tag}</Chip> : null}<span className="text-[10px] text-[var(--muted)]">{fa(c.questionCount || 0)} سؤال</span></span>
              </button>
            ))}
          </div>
        </section>

        <div className="sticky bottom-[calc(env(safe-area-inset-bottom)+96px)] pt-2">
          <Btn size="lg" block icon="play" loading={busy} onClick={start} disabled={!cat && mode !== "daily"}>شروع مسابقه</Btn>
        </div>
      </div>
    </div>
  );
}
export default function Play() { return <Suspense fallback={null}><PlayInner /></Suspense>; }
