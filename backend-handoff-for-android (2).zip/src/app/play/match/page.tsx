"use client";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Ring, useToast, tap, burst, flyEmoji } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, type Match } from "@/lib/api";

/**
 * 🎮 صفحهٔ مسابقه — منطق عیناً مطابق /api/matches:
 * زمان از serverNow/deadline سرور محاسبه می‌شود؛ پاسخ، کمک و next به سرور ارسال و وضعیت از پاسخ سرور گرفته می‌شود.
 */
function MatchInner() {
  const r = useRouter(); const sp = useSearchParams(); const toast = useToast(); const { user, refresh } = useSession();
  const id = sp.get("id") || "";
  const [m, setM] = useState<Match | null>(null);
  const [now, setNow] = useState(Date.now());
  const [offset, setOffset] = useState(0); // serverNow - Date.now()
  const [pick, setPick] = useState<number | null>(null);
  const [busy, setBusy] = useState(false);
  const [exitAsk, setExitAsk] = useState(false);
  const autoRef = useRef(false);

  const apply = useCallback((x: Match) => { setM(x); setOffset(x.serverNow - Date.now()); setPick(null); autoRef.current = false; }, []);
  useEffect(() => { (id ? get<{ match: Match | null }>(`matches?id=${id}`) : get<{ match: Match | null }>("matches")).then((d) => (d.match ? apply(d.match) : r.replace("/play"))).catch(() => r.replace("/play")); }, [id, apply, r]);
  useEffect(() => { const t = setInterval(() => setNow(Date.now()), 100); return () => clearInterval(t); }, []);

  const serverNow = now + offset;
  const answered = m?.answers.find((a) => a.round === m.round);
  const finished = m?.status === "finished";
  const preStart = m ? serverNow < m.roundAt : false;
  const total = m ? (m.deadline - m.roundAt) : 1;
  const remain = m ? Math.max(0, m.deadline - serverNow) : 0;
  const pct = remain / total;
  const timeUp = !!m && !answered && !preStart && remain <= 0;

  const act = useCallback(async (body: Record<string, unknown>) => {
    if (!m) return; setBusy(true);
    try { const x = await post<Match>("matches", { id: m.id, round: m.round, ...body }); apply(x); return x; }
    catch (e) { const msg = e instanceof Error ? e.message : "خطا"; toast(msg, "err"); if (/نوبت تغییر|پیدا نشد/.test(msg)) get<{ match: Match | null }>(`matches?id=${m.id}`).then((d) => d.match && apply(d.match)); }
    finally { setBusy(false); }
  }, [m, apply, toast]);

  // اتمام زمان → پاسخ -۱ (همان رفتار بازی اصلی)
  useEffect(() => { if (timeUp && !autoRef.current && !busy) { autoRef.current = true; act({ action: "answer", choice: -1 }).then((x) => { if (x) flyEmoji("⏰"); }); } }, [timeUp, busy, act]);
  useEffect(() => { if (finished) { refresh(); const won = m && m.rival ? m.score > m.rivalScore : (m?.answers.filter((a) => a.correct).length || 0) >= Math.ceil((m?.total || 1) / 2); if (won) burst(); } /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [finished]);

  const answer = async (i: number) => { if (!m || answered || busy || preStart) return; setPick(i); tap("medium"); const x = await act({ action: "answer", choice: i }); if (x) { const ok = x.question?.correct === i; tap(ok ? "success" : "error"); flyEmoji(ok ? ["🔥", "⚡", "🎯", "👏"][Math.floor(Math.random() * 4)] : "😬"); } };
  const help = (kind: string) => act({ action: "help", kind });
  const next = () => act({ action: "next" });

  if (!m) return <div className="min-h-dvh grid place-items-center"><div className="spinner" /></div>;

  /* ---------- نتیجه ---------- */
  if (finished) {
    const correct = m.answers.filter((a) => a.correct).length;
    const won = m.rival ? m.score > m.rivalScore : null;
    const rw = m.reward || { xp: 0, coins: 0, cups: 0 };
    return (
      <div className="min-h-dvh px-5 pt-[calc(env(safe-area-inset-top)+24px)] pb-8 flex flex-col anim-bg-in">
        <div className="text-center">
          <div className="text-[64px] anim-float">{won === null ? "🎓" : won ? "🏆" : m.score === m.rivalScore ? "🤝" : "💪"}</div>
          <h1 className="text-[26px] font-black mt-2 sheen">{won === null ? "تمرین تمام شد" : won ? "بردی! آفرین" : m.score === m.rivalScore ? "مساوی شد" : "این بار نشد"}</h1>
          <p className="text-[13px] text-[var(--muted)] mt-1">{fa(correct)} پاسخ درست از {fa(m.total)}</p>
        </div>
        <Card className="card-hero mt-6">
          <div className="flex items-center justify-around">
            <div className="text-center"><Avatar a={user?.avatar} name={user?.name} size={56} ring="var(--gold)" /><div className="font-black text-[22px] mt-2 text-[var(--gold)]">{fa(m.score)}</div><div className="text-[11px] text-[var(--muted)]">تو</div></div>
            {m.rival ? <><div className="text-[var(--muted)] font-black text-[20px]">VS</div><div className="text-center"><Avatar a={m.rival.avatar} name={m.rival.name} size={56} ring="var(--purple)" /><div className="font-black text-[22px] mt-2 text-[var(--purple)]">{fa(m.rivalScore)}</div><div className="text-[11px] text-[var(--muted)] max-w-[90px] truncate">{m.rival.name}</div></div></> : null}
          </div>
        </Card>
        <div className="grid grid-cols-3 gap-2 mt-4 stagger">
          {[{ i: "star", v: rw.xp, l: "امتیاز", c: "var(--purple)" }, { i: "coin", v: rw.coins, l: "سکه", c: "var(--gold)" }, { i: "trophy", v: rw.cups, l: "جام", c: "var(--green)" }].map((s) => (
            <div key={s.l} className="card !p-3 text-center"><span style={{ color: s.c }}><Icon name={s.i} size={22} className="mx-auto" /></span><b className="block text-[18px] mt-1">+{fa(s.v)}</b><span className="text-[11px] text-[var(--muted)]">{s.l}</span></div>
          ))}
        </div>
        <div className="mt-4 space-y-2">
          <h3 className="font-black text-[14px]">مرور پاسخ‌ها</h3>
          <div className="flex gap-1.5 flex-wrap">{m.answers.map((a) => <span key={a.round} className={`w-9 h-9 rounded-xl grid place-items-center font-black text-[12px] ${a.correct ? "bg-[var(--green)]/20 text-[var(--green)]" : "bg-[var(--red)]/20 text-[var(--red)]"}`}>{a.correct ? `+${fa(a.points)}` : "✕"}</span>)}</div>
        </div>
        <div className="mt-auto pt-6 flex gap-2">
          <Btn block variant="soft" icon="home" onClick={() => r.replace("/")}>خانه</Btn>
          <Btn block icon="refresh" onClick={() => r.replace(`/play?category=${m.category}`)}>بازی دوباره</Btn>
        </div>
      </div>
    );
  }

  const q = m.question!;
  const dim = m.usedHelps.fifty || [];
  const secondsLeft = Math.ceil(remain / 1000);
  const ringColor = pct > 0.5 ? "var(--green)" : pct > 0.25 ? "var(--gold)" : "var(--red)";
  return (
    <div className="min-h-dvh flex flex-col px-4 pt-[calc(env(safe-area-inset-top)+10px)] pb-[calc(env(safe-area-inset-bottom)+16px)]">
      {/* نوار بالا */}
      <div className="flex items-center gap-3">
        <button onClick={() => setExitAsk(true)} className="press w-10 h-10 rounded-2xl bg-[var(--panel2)] border border-[var(--line)] grid place-items-center"><Icon name="x" size={18} /></button>
        <div className="flex-1">
          <div className="flex justify-between text-[11px] text-[var(--muted)] mb-1"><span>سؤال {fa(m.round + 1)} از {fa(m.total)}</span><span>{{ ranked: "رتبه‌بندی", computer: "ربات", practice: "تمرین", daily: "روزانه", event: "رویداد", league: "لیگ", friendly: "دوستانه" }[m.mode] || m.mode}</span></div>
          <div className="flex gap-1">{Array.from({ length: m.total }).map((_, i) => { const a = m.answers.find((x) => x.round === i); return <span key={i} className={`h-1.5 flex-1 rounded-full ${a ? (a.correct ? "bg-[var(--green)]" : "bg-[var(--red)]") : i === m.round ? "bg-[var(--gold)]" : "bg-[#ffffff20]"}`} />; })}</div>
        </div>
        <Ring pct={preStart ? 1 : pct} size={52} stroke={5} color={ringColor}><b className={`text-[15px] ${secondsLeft <= 5 && !answered ? "text-[var(--red)] animate-pulse" : ""}`}>{preStart ? "…" : fa(secondsLeft)}</b></Ring>
      </div>

      {/* امتیازها */}
      <div className="flex items-center justify-between mt-4 card !p-3 !rounded-2xl">
        <div className="flex items-center gap-2"><Avatar a={user?.avatar} name={user?.name} size={36} ring="var(--gold)" /><div><div className="text-[11px] text-[var(--muted)]">تو</div><b className="text-[16px] text-[var(--gold)]">{fa(m.score)}</b></div></div>
        {m.rival ? <><span className="text-[var(--muted)] text-[12px] font-black">VS</span><div className="flex items-center gap-2 flex-row-reverse text-left"><Avatar a={m.rival.avatar} name={m.rival.name} size={36} ring="var(--purple)" /><div><div className="text-[11px] text-[var(--muted)] truncate max-w-[90px]">{m.rival.name}</div><b className="text-[16px] text-[var(--purple)]">{fa(m.rivalScore)}</b></div></div></> : <span className="text-[12px] text-[var(--muted)]">بدون حریف</span>}
      </div>

      {/* سؤال */}
      <div key={m.round} className="mt-4 rounded-3xl p-5 min-h-[120px] grid place-items-center text-center text-[17px] font-black leading-8 anim-q" style={{ background: "linear-gradient(90deg,#3b2850,#6b4f8d,#3b2850)", boxShadow: "0 20px 50px -20px #8960c5aa" }}>
        {preStart ? <span className="text-[var(--gold)] text-[28px] anim-pulse rounded-full px-6">آماده…</span> : q.title}
      </div>
      {m.usedHelps.hint ? <div className="mt-2 text-[12px] text-[var(--gold)] bg-[var(--gold)]/10 rounded-xl px-3 py-2 anim-drop flex gap-2"><Icon name="bulb" size={16} />{m.usedHelps.hint}</div> : null}

      {/* گزینه‌ها */}
      <div key={"o" + m.round} className="mt-4 space-y-2.5 flex-1">
        {!preStart && q.options.map((o, i) => {
          const isCorrect = answered && q.correct === i; const isWrong = answered && answered.choice === i && q.correct !== i;
          return (
            <button key={i} disabled={!!answered || busy} onClick={() => answer(i)} style={{ animationDelay: `${i * 0.08}s` }} className={`opt ${pick === i && !answered ? "pick" : ""} ${isCorrect ? "ok" : ""} ${isWrong ? "bad" : ""} ${dim.includes(i) && !answered ? "dim" : ""}`}>
              <span className="k">{["الف", "ب", "ج", "د"][i]}</span><span className="flex-1">{o}</span>
              {isCorrect ? <Icon name="check" size={20} strokeWidth={3} /> : isWrong ? <Icon name="x" size={20} strokeWidth={3} /> : null}
            </button>
          );
        })}
        {answered ? (
          <div className="anim-pop rounded-2xl p-4 bg-[#ffffff0a] border border-[var(--line)]">
            <div className="flex items-center justify-between"><b className={answered.correct ? "text-[var(--green)]" : "text-[var(--red)]"}>{answered.correct ? `درست! +${fa(answered.points)} امتیاز` : answered.choice === -1 ? "زمان تمام شد" : "پاسخ اشتباه"}</b>{m.rival ? <span className="text-[12px] text-[var(--muted)]">حریف: +{fa(answered.rivalPoints)}</span> : null}</div>
            {q.explanation ? <p className="text-[13px] text-[var(--muted)] leading-6 mt-1">{q.explanation}</p> : null}
          </div>
        ) : null}
      </div>

      {/* کمک‌ها / بعدی */}
      {answered ? (
        <Btn size="lg" block icon="forward" loading={busy} onClick={next} className="mt-3">{m.round < m.total - 1 ? "سؤال بعدی" : "مشاهدهٔ نتیجه"}</Btn>
      ) : (
        <div className="grid grid-cols-3 gap-2 mt-3">
          {[{ k: "fifty", i: "scissors", l: "حذف دو گزینه" }, { k: "hint", i: "bulb", l: "راهنما" }, { k: "time", i: "hourglass", l: "+۱۰ ثانیه" }].map((h) => {
            const left = m.helps[h.k] || 0; const used = !!(m.usedHelps as Record<string, unknown>)[h.k];
            return <button key={h.k} disabled={!left || used || busy || preStart} onClick={() => { tap("medium"); help(h.k); }} className={`press flex flex-col items-center gap-1 py-2.5 rounded-2xl border text-[11px] font-bold ${used ? "bg-[var(--purple)]/20 border-[var(--purple)] text-[var(--purple)]" : "bg-[var(--panel)] border-[var(--line)]"}`}><Icon name={h.i} size={20} />{h.l}<span className="text-[10px] text-[var(--muted)]">{used ? "استفاده شد" : `${fa(left)} باقی`}</span></button>;
          })}
        </div>
      )}

      {exitAsk ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-black/70 p-6 anim-fade" onClick={() => setExitAsk(false)}>
          <Card className="w-full max-w-[360px] text-center anim-pop" onClick={undefined}>
            <div className="text-4xl">🚪</div><b className="block mt-2 text-[16px]">از مسابقه خارج می‌شوی؟</b><p className="text-[12px] text-[var(--muted)] mt-1">مسابقهٔ ناتمام «رهاشده» ثبت می‌شود و پاداشی نمی‌گیری.</p>
            <div className="flex gap-2 mt-4"><Btn block variant="soft" onClick={() => setExitAsk(false)}>ادامه بازی</Btn><Btn block variant="danger" onClick={async () => { await post("matches", { action: "forfeit", id: m.id }).catch(() => {}); r.replace("/play"); }}>خروج</Btn></div>
          </Card>
        </div>
      ) : null}
    </div>
  );
}
export default function MatchPage() { return <Suspense fallback={null}><MatchInner /></Suspense>; }
