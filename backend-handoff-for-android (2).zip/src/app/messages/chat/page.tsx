"use client";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, IconBtn, useToast, tap } from "@/components/ui";
import { get, post, subscribe, ago, type Message, type Player } from "@/lib/api";

function ChatInner() {
  const id = useSearchParams().get("id") || ""; const r = useRouter(); const toast = useToast();
  const [msgs, setMsgs] = useState<Message[] | null>(null);
  const [other, setOther] = useState<Player | null>(null);
  const [text, setText] = useState("");
  const [busy, setBusy] = useState(false);
  const end = useRef<HTMLDivElement>(null);
  const load = useCallback(() => get<Message[]>(`messages?with=${id}`).then((m) => setMsgs((old) => (old && old.length === m.length ? old : m))).catch(() => setMsgs([])), [id]);
  useEffect(() => { load(); get<Player[]>("players?limit=200").then((p) => setOther(p.find((x) => x.id === id) || null)).catch(() => {}); const t = setInterval(load, 3000); const off = subscribe(["chat:message"], load); return () => { clearInterval(t); off(); }; }, [id, load]);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs?.length]);
  const send = async () => { const t = text.trim(); if (!t || busy) return; setBusy(true); setText(""); tap(); const tmp: Message = { id: "tmp" + Date.now(), from_id: "me", to_id: id, text: t, at: Date.now(), read: 0, from: "me" }; setMsgs((m) => [...(m || []), tmp]); try { await post("messages", { to: id, text: t }); load(); } catch (e) { toast(e instanceof Error ? e.message : "ارسال نشد", "err"); setText(t); } finally { setBusy(false); } };
  return (
    <div className="h-dvh flex flex-col">
      <div className="flex items-center gap-3 px-4 pt-[calc(env(safe-area-inset-top)+10px)] pb-3 bg-[var(--bg)]/90 backdrop-blur-xl border-b border-[var(--line)]">
        <IconBtn icon="back" onClick={() => r.back()} />
        <Avatar a={other?.avatar} name={other?.name} size={42} online={other?.online} />
        <div className="flex-1 min-w-0"><b className="block text-[15px] truncate">{other?.name || "بازیکن"}</b><span className="text-[11px] text-[var(--muted)]">{other ? (other.online ? "آنلاین" : `آخرین بازدید ${ago(other.lastSeen)}`) : ""}</span></div>
        <IconBtn icon="swords" className="!text-[var(--red)]" onClick={() => r.push(`/pvp?invite=${id}`)} aria-label="دعوت به نبرد" />
      </div>
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-2">
        {msgs === null ? <div className="spinner mx-auto mt-10" /> : msgs.length === 0 ? <p className="text-center text-[12px] text-[var(--muted)] mt-10">اولین پیام را بفرست 👋</p> : msgs.map((m) => (
          <div key={m.id} className={`flex ${m.from === "me" ? "justify-start flex-row-reverse" : "justify-start"} anim-pop`}>
            <div className={`max-w-[78%] px-4 py-2.5 text-[14px] leading-6 shadow-md ${m.from === "me" ? "bg-gradient-to-br from-[var(--purple)] to-[var(--purple2)] text-white rounded-[20px] rounded-bl-md" : "bg-[var(--panel2)] border border-[var(--line)] rounded-[20px] rounded-br-md"}`}>
              {m.text}<div className={`text-[10px] mt-1 flex items-center gap-1 ${m.from === "me" ? "text-white/70" : "text-[var(--muted)]"}`}>{ago(m.at)}{m.from === "me" ? <Icon name="check" size={12} /> : null}</div>
            </div>
          </div>
        ))}
        <div ref={end} />
      </div>
      <div className="px-3 pb-[calc(env(safe-area-inset-bottom)+10px)] pt-2 bg-[var(--bg)] border-t border-[var(--line)] flex items-center gap-2">
        <input value={text} onChange={(e) => setText(e.target.value)} onKeyDown={(e) => e.key === "Enter" && send()} placeholder="پیام بنویس…" className="flex-1 h-12 px-4 rounded-2xl bg-[var(--panel)] border border-[var(--line)] outline-none focus:border-[var(--purple)] text-[14px]" />
        <button onClick={send} disabled={!text.trim() || busy} className="press w-12 h-12 rounded-2xl btn-purple grid place-items-center"><Icon name="send" size={20} className="-scale-x-100" /></button>
      </div>
    </div>
  );
}
export default function Chat() { return <Suspense fallback={null}><ChatInner /></Suspense>; }
