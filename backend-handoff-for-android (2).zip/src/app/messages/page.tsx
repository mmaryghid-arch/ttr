"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Empty, PageHeader, Sheet, Skeleton } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, fa, ago, type Contact, type Player } from "@/lib/api";

export default function Messages() {
  const r = useRouter(); const { user } = useSession();
  const [list, setList] = useState<Contact[] | null>(null);
  const [pickOpen, setPickOpen] = useState(false);
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [q, setQ] = useState("");
  useEffect(() => { const load = () => get<Contact[]>("messages?scan=1").then(setList).catch(() => setList([])); load(); const t = setInterval(load, 6000); return () => clearInterval(t); }, []);
  useEffect(() => { if (pickOpen && !players) get<Player[]>("players?real=1&limit=200").then((p) => setPlayers(p.filter((x) => x.id !== user?.id))).catch(() => setPlayers([])); }, [pickOpen, players, user?.id]);
  return (
    <div>
      <PageHeader title="پیام‌ها" sub="گفت‌وگوی خصوصی با بازیکنان" back={() => r.back()} right={<Btn size="sm" icon="pen" onClick={() => setPickOpen(true)}>جدید</Btn>} />
      <div className="px-4 space-y-2">
        {list === null ? [1, 2, 3].map((i) => <Skeleton key={i} className="h-[72px]" />) : list.length === 0 ? <Empty icon="chat" title="هنوز گفت‌وگویی نداری" sub="روی «جدید» بزن و با یک بازیکن صحبت کن." action={<Btn icon="pen" onClick={() => setPickOpen(true)}>شروع گفت‌وگو</Btn>} /> : (
          <div className="stagger space-y-2">{list.map((c) => (
            <Card key={c.id} className="!p-3 flex items-center gap-3" onClick={() => r.push(`/messages/chat?id=${c.id}`)}>
              <Avatar a={c.avatar} name={c.name} size={48} online={c.online} />
              <div className="flex-1 min-w-0"><div className="flex items-center justify-between"><b className="text-[14px] truncate">{c.name || "بازیکن"}</b><span className="text-[10px] text-[var(--muted)]">{ago(c.lastAt)}</span></div><p className={`text-[12px] truncate ${c.unread ? "text-[var(--text)] font-bold" : "text-[var(--muted)]"}`}>{c.lastText}</p></div>
              {c.unread ? <span className="min-w-6 h-6 px-1.5 rounded-full bg-[var(--gold)] text-[#2a1d12] text-[11px] font-black grid place-items-center">{fa(c.unread)}</span> : <Icon name="forward" size={16} className="text-[var(--muted)]" />}
            </Card>
          ))}</div>
        )}
      </div>
      <Sheet open={pickOpen} onClose={() => setPickOpen(false)} title="انتخاب مخاطب">
        <label className="flex items-center gap-2 h-11 px-4 rounded-2xl bg-[#ffffff0a] border border-[var(--line)] mb-3"><Icon name="search" size={18} className="text-[var(--muted)]" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="نام بازیکن…" className="flex-1 bg-transparent outline-none text-[14px]" /></label>
        <div className="space-y-1 pb-4">{players === null ? <Skeleton className="h-[200px]" /> : players.filter((p) => !q || p.name.includes(q)).slice(0, 80).map((p) => <button key={p.id} onClick={() => { setPickOpen(false); r.push(`/messages/chat?id=${p.id}`); }} className="press w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#ffffff08] text-right"><Avatar a={p.avatar} name={p.name} size={40} online={p.online} /><span className="flex-1 min-w-0"><b className="block text-[13px] truncate">{p.name}</b><span className="text-[11px] text-[var(--muted)]">{p.isBot ? "ربات" : p.online ? "آنلاین" : ago(p.lastSeen)}</span></span></button>)}</div>
      </Sheet>
    </div>
  );
}
