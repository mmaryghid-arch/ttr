"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, Empty, PageHeader, Sheet, Skeleton, useToast } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, left, type Competition, type Match } from "@/lib/api";

type Tour = { id: string; title: string; category: string; startsAt: number; endsAt: number; description: string; open: boolean; orgLocked: boolean; joined: boolean; myScore: number; questionCount: number };
type Standing = { title: string; final: boolean; endsAt: number; rank: number | null; total: number; leaders: { id: string; name: string; rank: number; score: number }[] };

export default function Compete() {
  const r = useRouter(); const toast = useToast(); const { user } = useSession();
  const [tab, setTab] = useState<"league" | "event" | "tournament">("league");
  const [items, setItems] = useState<Competition[] | null>(null);
  const [cats, setCats] = useState<Record<string, string>>({});
  const [tours, setTours] = useState<Tour[] | null>(null);
  const [serverNow, setServerNow] = useState(Date.now());
  const [standing, setStanding] = useState<Standing | null>(null);
  const [busy, setBusy] = useState("");

  const load = useCallback(() => {
    if (tab === "tournament") { setTours(null); get<Tour[]>("tournaments").then(setTours).catch(() => setTours([])); return; }
    setItems(null);
    get<{ items: Competition[]; categories: { id: string; name: string }[]; serverNow: number }>(`competitions?kind=${tab}`).then((d) => { setItems(d.items); setServerNow(d.serverNow); setCats(Object.fromEntries(d.categories.map((c) => [c.id, c.name]))); }).catch((e) => { setItems([]); toast(e.message, "err"); });
  }, [tab, toast]);
  useEffect(load, [load]);

  const start = async (c: Competition) => {
    setBusy(c.id);
    try { const m = await post<Match>("matches", { action: "start", mode: tab === "league" ? "league" : "event", competitionId: c.id }); r.push(`/play/match?id=${m.id}`); }
    catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); }
    finally { setBusy(""); }
  };
  const showStanding = async (id: string) => { try { setStanding(await get<Standing>(`matches?standings=${id}`)); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } };
  const joinTour = async (t: Tour) => { setBusy(t.id); try { await post("tournaments?action=join", { id: t.id }); toast("عضو تورنمنت شدی 🏆", "ok"); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };

  const status = (s: number, e: number) => (serverNow < s ? { l: "به‌زودی", c: "var(--blue)" } : serverNow > e ? { l: "پایان‌یافته", c: "var(--muted)" } : { l: "در جریان", c: "var(--green)" });

  return (
    <div>
      <PageHeader title="مسابقات" sub="لیگ، رویداد و تورنمنت — مشترک با سایت" />
      <div className="px-4 space-y-4">
        <div className="flex p-1 rounded-2xl bg-[var(--panel)] border border-[var(--line)]">
          {[{ k: "league", l: "لیگ", i: "crown" }, { k: "event", l: "رویداد", i: "flag" }, { k: "tournament", l: "تورنمنت", i: "trophy" }].map((t) => (
            <button key={t.k} onClick={() => setTab(t.k as typeof tab)} className={`press flex-1 h-11 rounded-xl flex items-center justify-center gap-1.5 text-[13px] font-bold transition-all ${tab === t.k ? "btn-gold" : "text-[var(--muted)]"}`}><Icon name={t.i} size={18} />{t.l}</button>
          ))}
        </div>

        {tab !== "tournament" ? (
          items === null ? [1, 2].map((i) => <Skeleton key={i} className="h-[150px]" />) : items.length === 0 ? <Empty icon="trophy" title={`فعلاً ${tab === "league" ? "لیگی" : "رویدادی"} فعال نیست`} sub="مدیر از پنل سایت مسابقه می‌سازد و همین‌جا نمایش داده می‌شود." /> : (
            <div className="space-y-3 stagger">
              {items.map((c) => { const st = status(c.starts_at, c.ends_at); const open = st.l === "در جریان"; return (
                <Card key={c.id} className="card-hero relative overflow-hidden">
                  <div className="absolute -left-10 -top-10 w-36 h-36 rounded-full bg-[var(--gold)]/10" />
                  <div className="flex items-start gap-3">
                    <span className="w-12 h-12 rounded-2xl logo-tile grid place-items-center text-[#2a1d12] shrink-0"><Icon name={tab === "league" ? "crown" : "flag"} size={24} /></span>
                    <div className="flex-1 min-w-0"><b className="block text-[16px] leading-6">{c.title}</b><span className="text-[12px] text-[var(--muted)]">{cats[c.category] || c.category} · {fa(c.question_count)} سؤال · {fa(c.seconds)} ثانیه</span></div>
                    <Chip color={st.c}>{st.l}</Chip>
                  </div>
                  <div className="flex items-center gap-2 mt-3 text-[12px] text-[var(--muted)]"><Icon name="clock" size={14} />{serverNow < c.starts_at ? `شروع تا ${left(c.starts_at - serverNow)}` : serverNow > c.ends_at ? "تمام شد" : `${left(c.ends_at - serverNow)} باقی مانده`}</div>
                  <div className="flex gap-2 mt-4">
                    <Btn block variant="soft" icon="chart" onClick={() => showStanding(c.id)}>جدول</Btn>
                    <Btn block icon="play" disabled={!open} loading={busy === c.id} onClick={() => start(c)}>{open ? "شرکت (یک‌بار)" : "بسته"}</Btn>
                  </div>
                </Card>
              ); })}
            </div>
          )
        ) : (
          tours === null ? [1, 2].map((i) => <Skeleton key={i} className="h-[130px]" />) : tours.length === 0 ? <Empty icon="trophy" title="تورنمنتی وجود ندارد" /> : (
            <div className="space-y-3 stagger">
              {tours.map((t) => (
                <Card key={t.id}>
                  <div className="flex items-start gap-3">
                    <span className="w-12 h-12 rounded-2xl bg-[var(--purple)]/20 text-[var(--purple)] grid place-items-center shrink-0"><Icon name="trophy" size={24} /></span>
                    <div className="flex-1 min-w-0"><b className="block text-[15px]">{t.title}</b><span className="text-[12px] text-[var(--muted)]">{t.description || `${fa(t.questionCount)} سؤال`}</span></div>
                    <Chip color={t.open ? "var(--green)" : "var(--muted)"}>{t.open ? "باز" : "بسته"}</Chip>
                  </div>
                  <div className="flex gap-2 mt-4">
                    <Btn block variant="soft" icon="chart" onClick={() => showStanding(t.id)}>جدول</Btn>
                    {t.joined ? <Btn block variant="green" icon="check" disabled>عضو شدی · {fa(t.myScore)}</Btn> : <Btn block icon="plus" disabled={!t.open || t.orgLocked} loading={busy === t.id} onClick={() => joinTour(t)}>{t.orgLocked ? "ویژهٔ سازمان" : "عضویت"}</Btn>}
                  </div>
                </Card>
              ))}
            </div>
          )
        )}
      </div>

      <Sheet open={!!standing} onClose={() => setStanding(null)} title={standing ? `جدول «${standing.title}»` : ""}>
        {standing ? (
          <div className="pb-4">
            <div className="flex items-center justify-between card !p-3 mb-3"><span className="text-[13px]">رتبهٔ تو</span><b className="text-[var(--gold)] text-[18px]">{standing.rank ? `#${fa(standing.rank)}` : "شرکت نکرده‌ای"}</b><span className="text-[12px] text-[var(--muted)]">{fa(standing.total)} شرکت‌کننده</span></div>
            {standing.leaders.length === 0 ? <Empty title="هنوز کسی شرکت نکرده" /> : standing.leaders.map((l) => (
              <div key={l.id} className={`flex items-center gap-3 py-2.5 border-b border-[var(--line)] last:border-0 ${l.id === user?.id ? "text-[var(--gold)]" : ""}`}>
                <span className={`w-8 h-8 rounded-xl grid place-items-center font-black text-[13px] ${l.rank === 1 ? "logo-tile text-[#2a1d12]" : l.rank === 2 ? "bg-[#c0c0c0]/30" : l.rank === 3 ? "bg-[#cd7f32]/30" : "bg-[#ffffff0f]"}`}>{fa(l.rank)}</span>
                <Avatar a={null} name={l.name} size={34} />
                <span className="flex-1 font-bold text-[14px] truncate">{l.name}</span>
                <b>{fa(l.score)}</b>
              </div>
            ))}
            {standing.final ? <p className="text-center text-[12px] text-[var(--muted)] mt-3">نتیجهٔ نهایی</p> : null}
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}
