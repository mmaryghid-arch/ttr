"use client";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, Empty, Input, PageHeader, Sheet, Skeleton, useToast } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, ago, type Post, type Category } from "@/lib/api";

function FeedInner() {
  const r = useRouter(); const sp = useSearchParams(); const toast = useToast(); const { user } = useSession();
  const [posts, setPosts] = useState<Post[] | null>(null);
  const [compose, setCompose] = useState<"" | "post" | "story">((sp.get("compose") as "story" | null) || "");
  const [body, setBody] = useState("");
  const [story, setStory] = useState({ title: "", options: ["", "", "", ""], correct: 0, explanation: "", category: "general" });
  const [cats, setCats] = useState<Category[]>([]);
  const [busy, setBusy] = useState(false);
  const load = () => get<Post[]>("feed?type=posts").then(setPosts).catch(() => setPosts([]));
  useEffect(() => { load(); get<Category[]>("questions?category=_categories").then(setCats).catch(() => {}); }, []);

  const submitPost = async () => { setBusy(true); try { const d = await post<{ status: string }>("feed?type=post", { body, category: "work" }); toast(d.status === "pending" ? "پست برای تأیید مدیر ارسال شد ⏳" : "پست منتشر شد ✅", "ok"); setBody(""); setCompose(""); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(false); } };
  const submitStory = async () => { setBusy(true); try { const opts = story.options.map((o) => o.trim()).filter(Boolean); const d = await post<{ status: string }>("feed?type=story", { ...story, options: opts.length === 4 ? opts : [] }); toast(d.status === "pending" ? "استوری برای تأیید مدیر ارسال شد ⏳" : "استوری منتشر شد ✅ (۲۴ ساعت)", "ok"); setCompose(""); setStory({ title: "", options: ["", "", "", ""], correct: 0, explanation: "", category: "general" }); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(false); } };

  return (
    <div>
      <PageHeader title="فید تجربه‌ها" sub="تجربه‌های کاری همکاران" back={() => r.back()} right={<div className="flex gap-2"><Btn size="sm" variant="purple" icon="plus" onClick={() => setCompose("story")}>استوری</Btn><Btn size="sm" icon="pen" onClick={() => setCompose("post")}>پست</Btn></div>} />
      <div className="px-4 space-y-3">
        {posts === null ? [1, 2, 3].map((i) => <Skeleton key={i} className="h-[140px]" />) : posts.length === 0 ? <Empty icon="feed" title="هنوز پستی نیست" sub="اولین تجربه‌ات را به اشتراک بگذار." action={<Btn icon="pen" onClick={() => setCompose("post")}>نوشتن پست</Btn>} /> : (
          <div className="stagger space-y-3">{posts.map((p) => (
            <Card key={p.id}>
              <div className="flex items-center gap-3"><Avatar a={null} name={p.userName} size={42} /><div className="flex-1 min-w-0"><b className="block text-[14px] truncate">{p.userName}</b><span className="text-[11px] text-[var(--muted)]">{ago(p.createdAt)}</span></div><Chip color="var(--green)">{p.category === "work" ? "تجربهٔ کاری" : p.category}</Chip></div>
              <p className="text-[14px] leading-7 mt-3 whitespace-pre-wrap">{p.body}</p>
              {p.media && !p.media.startsWith("/api/") ? /* eslint-disable-next-line @next/next/no-img-element */ <img src={p.media} alt="" className="mt-3 rounded-2xl w-full max-h-[320px] object-cover" /> : null}
              <div className="flex items-center gap-4 mt-3 text-[12px] text-[var(--muted)]"><span className="flex items-center gap-1"><Icon name="heart" size={16} className="text-[var(--red)]" />{p.likes}</span>{p.userId !== user?.id ? <button className="press flex items-center gap-1" onClick={() => r.push(`/messages/chat?id=${p.userId}`)}><Icon name="chat" size={16} />پیام</button> : null}</div>
            </Card>
          ))}</div>
        )}
      </div>

      <Sheet open={compose === "post"} onClose={() => setCompose("")} title="تجربهٔ جدید">
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={5} maxLength={4000} placeholder="تجربه‌ات را بنویس… (حداقل ۳ حرف)" className="w-full p-4 rounded-2xl bg-[#ffffff0a] border border-[var(--line)] outline-none focus:border-[var(--purple)] text-[14px] leading-7" />
        <Btn block size="lg" className="mt-3 mb-4" icon="send" loading={busy} disabled={body.trim().length < 3} onClick={submitPost}>انتشار</Btn>
      </Sheet>
      <Sheet open={compose === "story"} onClose={() => setCompose("")} title="استوری سؤالی (۲۴ ساعته)">
        <div className="space-y-3 pb-4">
          <div className="flex flex-wrap gap-1.5">{cats.map((c) => <button key={c.id} onClick={() => setStory({ ...story, category: c.id })} className={`press h-8 px-3 rounded-xl text-[12px] font-bold border ${story.category === c.id ? "text-[#2a1d12] border-transparent" : "border-[var(--line)]"}`} style={story.category === c.id ? { background: c.color } : undefined}>{c.name}</button>)}</div>
          <textarea value={story.title} onChange={(e) => setStory({ ...story, title: e.target.value })} rows={3} maxLength={500} placeholder="متن سؤال (حداقل ۵ حرف)" className="w-full p-4 rounded-2xl bg-[#ffffff0a] border border-[var(--line)] outline-none focus:border-[var(--purple)] text-[14px] leading-7" />
          {story.options.map((o, i) => <div key={i} className="flex items-center gap-2"><button onClick={() => setStory({ ...story, correct: i })} className={`press w-10 h-10 rounded-xl grid place-items-center font-black shrink-0 ${story.correct === i ? "bg-[var(--green)] text-[#0c2a1c]" : "bg-[#ffffff0f]"}`}>{["الف", "ب", "ج", "د"][i]}</button><Input value={o} onChange={(e) => { const opts = [...story.options]; opts[i] = e.target.value; setStory({ ...story, options: opts }); }} placeholder={`گزینهٔ ${i + 1}${story.correct === i ? " (صحیح)" : ""}`} /></div>)}
          <Input label="توضیح پاسخ (اختیاری)" value={story.explanation} onChange={(e) => setStory({ ...story, explanation: e.target.value })} />
          <Btn block size="lg" icon="send" variant="purple" loading={busy} disabled={story.title.trim().length < 5} onClick={submitStory}>انتشار استوری</Btn>
        </div>
      </Sheet>
    </div>
  );
}
export default function Feed() { return <Suspense fallback={null}><FeedInner /></Suspense>; }
