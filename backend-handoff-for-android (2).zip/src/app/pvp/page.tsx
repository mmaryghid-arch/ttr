"use client";
import { Suspense, useCallback, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, Empty, PageHeader, Sheet, Skeleton, useToast, tap } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, ago, type Player, type PvpMini, type PvpState, type Category } from "@/lib/api";

type Inbox = { me: string; serverNow: number; incoming: PvpMini[]; outgoing: PvpMini[]; active: PvpMini[]; results: PvpMini[] };

function PvpInner() {
  const r = useRouter(); const sp = useSearchParams(); const toast = useToast(); const { user } = useSession();
  const [inbox, setInbox] = useState<Inbox | null>(null);
  const [players, setPlayers] = useState<Player[] | null>(null);
  const [cats, setCats] = useState<Category[]>([]);
  const [q, setQ] = useState("");
  const [target, setTarget] = useState<Player | null>(null);
  const [cat, setCat] = useState("general");
  const [busy, setBusy] = useState("");
  const [tab, setTab] = useState<"players" | "inbox">("players");

  const load = useCallback(() => {
    get<Inbox>("pvp?action=inbox").then(setInbox).catch(() => {});
    get<Player[]>("players?real=1&limit=200").then((p) => setPlayers(p.filter((x) => x.id !== user?.id))).catch(() => setPlayers([]));
  }, [user?.id]);
  useEffect(() => { load(); get<Category[]>("questions?category=_categories").then(setCats).catch(() => {}); const t = setInterval(() => get<Inbox>("pvp?action=inbox").then(setInbox).catch(() => {}), 5000); return () => clearInterval(t); }, [load]);
  useEffect(() => { const inv = sp.get("invite"); if (inv && players) { const p = players.find((x) => x.id === inv); if (p) setTarget(p); } }, [sp, players]);
  useEffect(() => { if (inbox && (inbox.incoming.length || inbox.active.length)) setTab("inbox"); /* eslint-disable-next-line react-hooks/exhaustive-deps */ }, [!!inbox]);

  const invite = async () => {
    if (!target) return; setBusy("invite");
    try { const d = await post<{ ok: boolean; already?: boolean; battle: PvpState }>("pvp?action=invite", { to: target.id, category: cat }); toast(d.already ? "نبرد بازی با این بازیکن از قبل وجود دارد" : "دعوت ارسال شد ⚔️ منتظر پذیرش…", "ok"); setTarget(null); r.push(`/pvp/battle?id=${d.battle.id}`); }
    catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); }
    finally { setBusy(""); }
  };
  const act = async (action: string, id: string) => { setBusy(id + action); try { const d = await post<{ battle?: PvpState }>(`pvp?action=${action}`, { id }); if (action === "accept" && d.battle) r.push(`/pvp/battle?id=${id}`); else load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); load(); } finally { setBusy(""); } };

  const list = (players || []).filter((p) => !q || p.name.includes(q));
  const online = list.filter((p) => p.online && !p.isBot), rest = list.filter((p) => !(p.online && !p.isBot));
  const pending = (inbox?.incoming.length || 0) + (inbox?.active.length || 0);

  const Row = ({ p }: { p: Player }) => (
    <button onClick={() => { tap(); setTarget(p); }} className="press w-full flex items-center gap-3 p-3 rounded-2xl bg-[var(--panel)] border border-[var(--line)] text-right">
      <Avatar a={p.avatar} name={p.name} size={46} online={p.online} />
      <span className="flex-1 min-w-0"><b className="block text-[14px] truncate">{p.name}</b><span className="text-[11px] text-[var(--muted)]">سطح {fa(p.level)} · {fa(p.wins)} برد {p.isBot ? "· ربات" : p.online ? "· آنلاین" : `· ${ago(p.lastSeen)}`}</span></span>
      <span className="w-9 h-9 rounded-xl bg-[var(--red)]/15 text-[var(--red)] grid place-items-center"><Icon name="swords" size={18} /></span>
    </button>
  );
  const Battle = ({ b, kind }: { b: PvpMini; kind: "in" | "out" | "active" | "done" }) => (
    <Card className={`!p-3 flex items-center gap-3 ${kind === "in" ? "border-[var(--gold)]/60 anim-pulse" : ""}`} onClick={kind === "done" || kind === "active" ? () => r.push(`/pvp/battle?id=${b.id}`) : undefined}>
      <Avatar a={b.opponent.avatar} name={b.opponent.name} size={44} online={b.opponent.online} />
      <div className="flex-1 min-w-0">
        <b className="block text-[14px] truncate">{b.opponent.name}</b>
        <span className="text-[11px] text-[var(--muted)]">{kind === "in" ? "تو را به نبرد دعوت کرده" : kind === "out" ? "منتظر پذیرش…" : kind === "active" ? "نبرد در جریان است!" : b.winnerId === user?.id ? `بردی ${fa(b.myScore)} – ${fa(b.oppScore)}` : b.winnerId ? `باختی ${fa(b.myScore)} – ${fa(b.oppScore)}` : `مساوی ${fa(b.myScore)}`} · {ago(b.at)}</span>
      </div>
      {kind === "in" ? <><Btn size="sm" variant="ghost" loading={busy === b.id + "decline"} onClick={() => act("decline", b.id)}>رد</Btn><Btn size="sm" variant="green" icon="check" loading={busy === b.id + "accept"} onClick={() => act("accept", b.id)}>قبول</Btn></> : null}
      {kind === "out" ? <Btn size="sm" variant="ghost" loading={busy === b.id + "cancel"} onClick={() => act("cancel", b.id)}>لغو</Btn> : null}
      {kind === "active" ? <Btn size="sm" icon="play" onClick={() => r.push(`/pvp/battle?id=${b.id}`)}>ورود</Btn> : null}
      {kind === "done" ? <Chip color={b.winnerId === user?.id ? "var(--green)" : b.winnerId ? "var(--red)" : "var(--muted)"}>{b.winnerId === user?.id ? "برد" : b.winnerId ? "باخت" : "مساوی"}</Chip> : null}
    </Card>
  );

  return (
    <div>
      <PageHeader title="نبرد زنده" sub="بازیکن‌به‌بازیکن · هم‌زمان · ۵ سؤال ۱۵ ثانیه‌ای" right={<Btn size="sm" variant="soft" icon="refresh" onClick={load}>تازه‌سازی</Btn>} />
      <div className="px-4 space-y-4">
        <div className="flex p-1 rounded-2xl bg-[var(--panel)] border border-[var(--line)]">
          <button onClick={() => setTab("players")} className={`press flex-1 h-11 rounded-xl text-[13px] font-bold flex items-center justify-center gap-1.5 ${tab === "players" ? "btn-purple" : "text-[var(--muted)]"}`}><Icon name="users" size={18} />بازیکنان</button>
          <button onClick={() => setTab("inbox")} className={`press flex-1 h-11 rounded-xl text-[13px] font-bold flex items-center justify-center gap-1.5 relative ${tab === "inbox" ? "btn-purple" : "text-[var(--muted)]"}`}><Icon name="bell" size={18} />نبردهای من{pending ? <span className="absolute top-1 left-3 min-w-5 h-5 px-1 rounded-full bg-[var(--red)] text-[#2a0d14] text-[11px] font-black grid place-items-center">{fa(pending)}</span> : null}</button>
        </div>

        {tab === "players" ? (
          <>
            <label className="flex items-center gap-2 h-12 px-4 rounded-2xl bg-[var(--panel)] border border-[var(--line)]"><Icon name="search" size={18} className="text-[var(--muted)]" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جست‌وجوی بازیکن…" className="flex-1 bg-transparent outline-none text-[14px]" /></label>
            {players === null ? [1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-[72px]" />) : (
              <>
                {online.length ? <section><h3 className="text-[13px] font-black text-[var(--green)] mb-2 flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-[var(--green)] animate-pulse" />آنلاین ({fa(online.length)})</h3><div className="space-y-2 stagger">{online.map((p) => <Row key={p.id} p={p} />)}</div></section> : null}
                <section><h3 className="text-[13px] font-black text-[var(--muted)] mb-2">همهٔ بازیکنان</h3>{rest.length === 0 && !online.length ? <Empty icon="users" title="بازیکنی پیدا نشد" /> : <div className="space-y-2">{rest.slice(0, 60).map((p) => <Row key={p.id} p={p} />)}</div>}</section>
              </>
            )}
          </>
        ) : (
          inbox === null ? [1, 2].map((i) => <Skeleton key={i} className="h-[72px]" />) : (
            <div className="space-y-4">
              {inbox.incoming.length ? <section><h3 className="text-[13px] font-black mb-2 text-[var(--gold)]">دعوت‌های دریافتی</h3><div className="space-y-2">{inbox.incoming.map((b) => <Battle key={b.id} b={b} kind="in" />)}</div></section> : null}
              {inbox.active.length ? <section><h3 className="text-[13px] font-black mb-2 text-[var(--green)]">در جریان</h3><div className="space-y-2">{inbox.active.map((b) => <Battle key={b.id} b={b} kind="active" />)}</div></section> : null}
              {inbox.outgoing.length ? <section><h3 className="text-[13px] font-black mb-2 text-[var(--muted)]">دعوت‌های ارسالی</h3><div className="space-y-2">{inbox.outgoing.map((b) => <Battle key={b.id} b={b} kind="out" />)}</div></section> : null}
              <section><h3 className="text-[13px] font-black mb-2 text-[var(--muted)]">نتایج اخیر</h3>{inbox.results.length === 0 ? <Empty icon="swords" title="هنوز نبردی نداشتی" sub="از تب بازیکنان یک حریف واقعی انتخاب کن." /> : <div className="space-y-2">{inbox.results.map((b) => <Battle key={b.id} b={b} kind="done" />)}</div>}</section>
            </div>
          )
        )}
      </div>

      <Sheet open={!!target} onClose={() => setTarget(null)} title="دعوت به نبرد">
        {target ? (
          <div className="pb-4">
            <div className="flex items-center gap-3 mb-4"><Avatar a={target.avatar} name={target.name} size={56} ring="var(--red)" online={target.online} /><div><b className="block text-[16px]">{target.name}</b><span className="text-[12px] text-[var(--muted)]">سطح {fa(target.level)} · {fa(target.wins)} برد از {fa(target.played)} بازی</span></div></div>
            {target.isBot ? <p className="text-[12px] text-[var(--red)] bg-[var(--red)]/10 rounded-xl p-3 mb-3">این بازیکن ربات است؛ سرور نبرد زنده با ربات را نمی‌پذیرد. برای بازی با ربات از «نبرد با ربات» در بخش بازی استفاده کن.</p> : null}
            <h4 className="text-[13px] font-bold text-[var(--muted)] mb-2">دستهٔ سؤال‌ها</h4>
            <div className="flex flex-wrap gap-2 mb-5">{cats.filter((c) => c.active !== 0).map((c) => <button key={c.id} onClick={() => setCat(c.id)} className={`press h-9 px-3 rounded-xl text-[12px] font-bold border ${cat === c.id ? "border-transparent text-[#2a1d12]" : "border-[var(--line)]"}`} style={cat === c.id ? { background: c.color } : undefined}>{c.name}</button>)}</div>
            <div className="flex gap-2"><Btn block variant="soft" icon="chat" onClick={() => r.push(`/messages/chat?id=${target.id}`)}>پیام</Btn><Btn block variant="danger" icon="swords" loading={busy === "invite"} onClick={invite}>ارسال دعوت</Btn></div>
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}
export default function Pvp() { return <Suspense fallback={null}><PvpInner /></Suspense>; }
