"use client";
import { Suspense, useCallback, useEffect, useRef, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Ring, useToast, tap, burst, flyEmoji } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, subscribe, type PvpState } from "@/lib/api";

/**
 * ⚔️ نبرد زندهٔ هم‌زمان — عین قرارداد /api/pvp:
 * پنجرهٔ هر سؤال = startedAt + k*(15s+2.5s)؛ پاسخ با {q,i}؛ نتیجه فقط از سرور.
 * رویدادها با SSE (/api/events?token=) + polling پشتیبان هر ۲ ثانیه.
 */
function PvpBattleInner() {
  const id = useSearchParams().get("id") || "";
  const r = useRouter(); const toast = useToast(); const { user, refresh } = useSession();
  const [s, setS] = useState<PvpState | null>(null);
  const [now, setNow] = useState(Date.now());
  const [offset, setOffset] = useState(0);
  const [pick, setPick] = useState<Record<number, number>>({});
  const [busy, setBusy] = useState(false);
  const done = useRef(false);

  const load = useCallback(async () => { try { const x = await get<PvpState>(`pvp?action=state&id=${id}`); setS(x); setOffset(x.serverNow - Date.now()); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } }, [id, toast]);
  useEffect(() => { load(); const t = setInterval(load, 2000); const tick = setInterval(() => setNow(Date.now()), 100); return () => { clearInterval(t); clearInterval(tick); }; }, [load]);
  useEffect(() => {
    return subscribe(["pvp:update", "pvp:start", "pvp:reveal", "pvp:opp-answered", "pvp:finished", "pvp:result"], load);
  }, [load]);
  useEffect(() => { if (s?.status === "finished" && !done.current) { done.current = true; refresh(); post("pvp?action=ack", { id }).catch(() => {}); if (s.result?.winnerId === user?.id) burst(); } }, [s?.status, s?.result, user?.id, id, refresh]);

  const serverNow = now + offset;
  if (!s) return <div className="min-h-dvh grid place-items-center"><div className="spinner" /></div>;
  const opp = s.opponent;
  const SEC = (s.seconds || 15) * 1000, GAP = s.gap || 2500;
  const k = s.startedAt ? Math.floor((serverNow - s.startedAt) / (SEC + GAP)) : -1;
  const qStart = s.startedAt + Math.max(0, k) * (SEC + GAP);
  const inGap = serverNow - qStart > SEC;
  const remain = Math.max(0, qStart + SEC - serverNow);

  const answer = async (i: number) => {
    if (busy || pick[k] !== undefined || s.myAnswered?.[k]) return; setPick((p) => ({ ...p, [k]: i })); setBusy(true); tap("medium");
    try { const d = await post<{ ok: boolean; correct: boolean | null; late: boolean }>("pvp?action=answer", { id, q: k, i }); if (d.late) toast("دیر شد!", "err"); else { tap(d.correct ? "success" : "error"); flyEmoji(d.correct ? "⚡" : "😬"); } load(); }
    catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); }
    finally { setBusy(false); }
  };

  const Head = ({ mid }: { mid?: React.ReactNode }) => (
    <div className="flex items-center justify-between card card-hero !p-3 !rounded-2xl">
      <div className="flex items-center gap-2"><Avatar a={user?.avatar} name={user?.name} size={40} ring="var(--gold)" /><div><div className="text-[11px] text-[var(--muted)]">تو</div><b className="text-[13px]">{user?.name}</b></div></div>
      {mid ?? <span className="text-[var(--red)] font-black text-[18px]">VS</span>}
      <div className="flex items-center gap-2 flex-row-reverse text-left"><Avatar a={opp.avatar} name={opp.name} size={40} ring="var(--purple)" online={opp.online} /><div><div className="text-[11px] text-[var(--muted)]">حریف</div><b className="text-[13px] truncate max-w-[90px] block">{opp.name}</b></div></div>
    </div>
  );
  const wrap = (c: React.ReactNode) => <div className="min-h-dvh flex flex-col px-4 pt-[calc(env(safe-area-inset-top)+10px)] pb-[calc(env(safe-area-inset-bottom)+16px)] gap-4">{c}</div>;

  /* ---------- در انتظار پذیرش ---------- */
  if (s.status === "pending") {
    const exp = Math.max(0, s.expiresAt - serverNow);
    return wrap(<>
      <div className="flex items-center gap-3"><button onClick={() => r.back()} className="press w-10 h-10 rounded-2xl bg-[var(--panel2)] border border-[var(--line)] grid place-items-center"><Icon name="back" size={18} /></button><h1 className="font-black text-[18px]">دعوت به نبرد</h1></div>
      <Head />
      <div className="flex-1 grid place-items-center text-center">
        <div className="anim-pop">
          <Ring pct={exp / 180000} size={120} stroke={8} color="var(--purple)"><div><b className="text-[26px] block">{fa(Math.ceil(exp / 1000))}</b><span className="text-[10px] text-[var(--muted)]">ثانیه</span></div></Ring>
          <p className="mt-5 text-[14px] text-[var(--muted)] leading-7">{s.iAmA ? `منتظر پذیرش ${opp.name}…` : `${opp.name} تو را به نبرد دعوت کرده!`}</p>
        </div>
      </div>
      {s.iAmA ? <Btn block variant="ghost" onClick={async () => { await post("pvp?action=cancel", { id }).catch(() => {}); r.replace("/pvp"); }}>لغو دعوت</Btn> :
        <div className="flex gap-2"><Btn block variant="ghost" onClick={async () => { await post("pvp?action=decline", { id }).catch(() => {}); r.replace("/pvp"); }}>رد</Btn><Btn block variant="green" icon="check" onClick={async () => { try { await post("pvp?action=accept", { id }); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } }}>قبول و شروع</Btn></div>}
    </>);
  }
  if (["declined", "cancelled", "expired"].includes(s.status)) return wrap(<>
    <Head /><div className="flex-1 grid place-items-center text-center"><div><div className="text-5xl">🙁</div><b className="block mt-3 text-[16px]">{s.status === "declined" ? "دعوت رد شد" : s.status === "cancelled" ? "دعوت لغو شد" : "دعوت منقضی شد"}</b></div></div>
    <Btn block icon="back" onClick={() => r.replace("/pvp")}>بازگشت</Btn>
  </>);

  /* ---------- نتیجه ---------- */
  if (s.status === "finished" && s.result) {
    const R = s.result; const won = R.winnerId === user?.id, draw = !R.winnerId;
    return (
      <div className="min-h-dvh px-4 pt-[calc(env(safe-area-inset-top)+20px)] pb-8 anim-bg-in">
        <div className="text-center"><div className="text-[64px] anim-float">{won ? "🏆" : draw ? "🤝" : "💪"}</div><h1 className="text-[26px] font-black sheen">{won ? "پیروز شدی!" : draw ? "مساوی!" : "باختی، ولی نزدیک بود"}</h1></div>
        <Card className="card-hero mt-5">
          <div className="flex items-center justify-around">
            <div className="text-center"><Avatar a={user?.avatar} name={user?.name} size={56} ring="var(--gold)" /><b className="block text-[24px] mt-2 text-[var(--gold)]">{fa(R.myScore)}</b><span className="text-[11px] text-[var(--muted)]">{fa(R.myCorrect)} درست · {fa(Math.round(R.myMs / 1000))}ث</span></div>
            <span className="text-[var(--muted)] font-black">VS</span>
            <div className="text-center"><Avatar a={opp.avatar} name={opp.name} size={56} ring="var(--purple)" /><b className="block text-[24px] mt-2 text-[var(--purple)]">{fa(R.oppScore)}</b><span className="text-[11px] text-[var(--muted)]">{fa(R.oppCorrect)} درست · {fa(Math.round(R.oppMs / 1000))}ث</span></div>
          </div>
        </Card>
        <div className="mt-4 space-y-2 stagger">
          {R.perQ.map((q, i) => (
            <div key={i} className="card !p-3">
              <div className="flex items-start gap-2"><span className="w-7 h-7 rounded-lg bg-[#ffffff10] grid place-items-center text-[12px] font-black shrink-0">{fa(i + 1)}</span><p className="text-[13px] font-bold leading-6 flex-1">{q.title}</p></div>
              <div className="flex gap-2 mt-2 text-[11px]"><span className={`px-2 py-1 rounded-lg ${q.myPick === q.correct ? "bg-[var(--green)]/20 text-[var(--green)]" : "bg-[var(--red)]/20 text-[var(--red)]"}`}>تو: {q.myPick >= 0 ? q.options[q.myPick] : "—"}</span><span className={`px-2 py-1 rounded-lg ${q.oppPick === q.correct ? "bg-[var(--green)]/20 text-[var(--green)]" : "bg-[var(--red)]/20 text-[var(--red)]"}`}>حریف: {q.oppPick >= 0 ? q.options[q.oppPick] : "—"}</span></div>
              <p className="text-[11px] text-[var(--muted)] mt-1.5">✅ {q.options[q.correct]}{q.explanation ? ` — ${q.explanation}` : ""}</p>
            </div>
          ))}
        </div>
        <div className="flex gap-2 mt-5"><Btn block variant="soft" icon="back" onClick={() => r.replace("/pvp")}>بازگشت</Btn><Btn block variant="danger" icon="refresh" onClick={async () => { try { const d = await post<{ battle: PvpState }>("pvp?action=rematch", { id }); r.replace(`/pvp/battle?id=${d.battle.id}`); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } }}>بازی مجدد</Btn></div>
      </div>
    );
  }
  if (s.status === "finished") return wrap(<><Head /><div className="flex-1 grid place-items-center"><div className="spinner" /></div></>);

  /* ---------- شمارش معکوس ---------- */
  if (k < 0) {
    const cd = Math.ceil((s.startedAt - serverNow) / 1000);
    return wrap(<><Head /><div className="flex-1 grid place-items-center"><div key={cd} className="text-[96px] font-black text-[var(--gold)] anim-bg-in">{cd > 0 ? fa(cd) : "⚡"}</div></div><p className="text-center text-[13px] text-[var(--muted)]">نبرد هم‌زمان شروع می‌شود… آماده باش!</p></>);
  }
  /* ---------- پایان سؤال‌ها، در انتظار حریف ---------- */
  if (k >= s.qCount) return wrap(<><Head /><div className="flex-1 grid place-items-center text-center"><div><div className="spinner mx-auto" /><p className="mt-4 text-[13px] text-[var(--muted)]">در انتظار نتیجهٔ نهایی…</p></div></div></>);

  const q = s.questions?.[k]; const mine = pick[k] ?? -2; const rv = s.reveal?.[k];
  const answeredThis = s.myAnswered?.[k] || mine >= 0;
  return wrap(<>
    <Head mid={<div className="text-center"><div className="text-[11px] text-[var(--muted)]">سؤال</div><b className="text-[16px]">{fa(k + 1)}/{fa(s.qCount)}</b></div>} />
    <div className="flex items-center justify-between">
      <div className="flex gap-1">{Array.from({ length: s.qCount }).map((_, i) => <span key={i} className={`w-7 h-1.5 rounded-full ${s.reveal?.[i] ? (s.reveal[i]!.myPick === s.reveal[i]!.correct ? "bg-[var(--green)]" : "bg-[var(--red)]") : i === k ? "bg-[var(--gold)]" : "bg-[#ffffff20]"}`} />)}</div>
      <Ring pct={inGap ? 0 : remain / SEC} size={52} stroke={5} color={remain / SEC > 0.4 ? "var(--green)" : "var(--red)"}><b className="text-[15px]">{inGap ? "✓" : fa(Math.ceil(remain / 1000))}</b></Ring>
    </div>
    <div key={k} className="rounded-3xl p-5 min-h-[120px] grid place-items-center text-center text-[17px] font-black leading-8 anim-q" style={{ background: "linear-gradient(90deg,#3b2850,#6b4f8d,#3b2850)" }}>{q?.title || "…"}</div>
    <div key={"o" + k} className="space-y-2.5 flex-1">
      {q?.options.map((o, i) => { const cls = rv ? (rv.correct === i ? "ok" : rv.myPick === i ? "bad" : "") : mine === i ? "pick" : ""; return (
        <button key={i} disabled={answeredThis || inGap || busy} onClick={() => answer(i)} style={{ animationDelay: `${i * 0.08}s` }} className={`opt ${cls}`}>
          <span className="k">{["الف", "ب", "ج", "د"][i]}</span><span className="flex-1">{o}</span>
          {rv && rv.oppPick === i ? <span className="text-[10px] px-2 py-0.5 rounded-full bg-[var(--purple)]/30 text-[var(--purple)]">حریف</span> : null}
        </button>
      ); })}
    </div>
    <div className="flex items-center justify-between text-[12px] text-[var(--muted)]">
      <span className="flex items-center gap-1.5">{answeredThis ? <><Icon name="check" size={14} className="text-[var(--green)]" />پاسخ تو ثبت شد</> : "گزینه را انتخاب کن"}</span>
      <span className="flex items-center gap-1.5">{s.oppAnswered?.[k] ? <><Icon name="check" size={14} className="text-[var(--purple)]" />حریف پاسخ داد</> : <><span className="spinner !w-3 !h-3 !border-2" />حریف در حال فکر…</>}</span>
    </div>
  </>);
}
export default function PvpBattle() { return <Suspense fallback={null}><PvpBattleInner /></Suspense>; }
