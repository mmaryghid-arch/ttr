"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Card, Empty, PageHeader, Skeleton } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, fa, type Player, type Tribe } from "@/lib/api";

export default function Leaderboard() {
  const r = useRouter(); const { user } = useSession();
  const [scope, setScope] = useState<"players" | "week" | "tribes">("players");
  const [rows, setRows] = useState<(Player | Tribe)[] | null>(null);
  useEffect(() => { setRows(null); get<(Player | Tribe)[]>(`leaderboard?scope=${scope}`).then(setRows).catch(() => setRows([])); }, [scope]);
  const isTribe = scope === "tribes";
  const top3 = rows?.slice(0, 3) || [];
  const medal = ["logo-tile text-[#2a1d12]", "bg-[#c0c0c0]/40", "bg-[#cd7f32]/40"];
  return (
    <div>
      <PageHeader title="تالار افتخار" sub="رتبه‌بندی مشترک با سایت" back={() => r.back()} />
      <div className="px-4 space-y-4">
        <div className="flex p-1 rounded-2xl bg-[var(--panel)] border border-[var(--line)]">{[{ k: "players", l: "کل", i: "crown" }, { k: "week", l: "این هفته", i: "fire" }, { k: "tribes", l: "قبیله‌ها", i: "shield" }].map((t) => <button key={t.k} onClick={() => setScope(t.k as typeof scope)} className={`press flex-1 h-11 rounded-xl text-[13px] font-bold flex items-center justify-center gap-1.5 ${scope === t.k ? "btn-gold" : "text-[var(--muted)]"}`}><Icon name={t.i} size={18} />{t.l}</button>)}</div>
        {rows === null ? <Skeleton className="h-[400px]" /> : rows.length === 0 ? <Empty icon="crown" title="هنوز رتبه‌ای ثبت نشده" /> : (
          <>
            <div className="flex items-end justify-center gap-3 pt-6 stagger">
              {[top3[1], top3[0], top3[2]].map((x, i) => x && (
                <div key={x.id} className={`flex flex-col items-center ${i === 1 ? "-translate-y-4" : ""}`}>
                  <div className={`${i === 1 ? "anim-float" : ""}`}>{isTribe ? <span className="w-16 h-16 rounded-3xl grid place-items-center text-[30px]" style={{ background: `color-mix(in srgb, ${(x as Tribe).logoColor} 30%, #241b30)` }}>{(x as Tribe).logoEmoji}</span> : <Avatar a={(x as Player).avatar} name={x.name} size={i === 1 ? 76 : 60} ring={i === 1 ? "var(--gold)" : i === 0 ? "#c0c0c0" : "#cd7f32"} />}</div>
                  <span className={`-mt-3 w-7 h-7 rounded-full grid place-items-center text-[12px] font-black ring-2 ring-[var(--bg)] ${medal[i === 1 ? 0 : i === 0 ? 1 : 2]}`}>{fa(i === 1 ? 1 : i === 0 ? 2 : 3)}</span>
                  <b className="text-[12px] mt-1 max-w-[90px] truncate">{x.name}</b>
                  <span className="text-[11px] text-[var(--gold)]">{fa(scope === "week" ? (x as Player).weekXp : x.xp)}</span>
                </div>
              ))}
            </div>
            <div className="space-y-2">
              {rows.slice(3).map((x, i) => (
                <Card key={x.id} className={`!p-3 flex items-center gap-3 ${x.id === user?.id ? "border-[var(--gold)]" : ""}`} onClick={isTribe ? () => r.push(`/tribes/detail?id=${x.id}`) : undefined}>
                  <span className="w-7 text-center font-black text-[13px] text-[var(--muted)]">{fa(i + 4)}</span>
                  {isTribe ? <span className="w-11 h-11 rounded-2xl grid place-items-center text-[22px]" style={{ background: `color-mix(in srgb, ${(x as Tribe).logoColor} 25%, transparent)` }}>{(x as Tribe).logoEmoji}</span> : <Avatar a={(x as Player).avatar} name={x.name} size={44} />}
                  <div className="flex-1 min-w-0"><b className="block text-[14px] truncate">{x.name}{x.id === user?.id ? " (تو)" : ""}</b><span className="text-[11px] text-[var(--muted)]">{isTribe ? `${fa((x as Tribe).memberCount)} عضو · ${fa((x as Tribe).wins)} برد` : `سطح ${fa((x as Player).level)} · ${fa((x as Player).wins)} برد`}</span></div>
                  <b className="text-[var(--gold)]">{fa(scope === "week" ? (x as Player).weekXp : x.xp)}</b>
                </Card>
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  );
}
