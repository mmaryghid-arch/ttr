"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, PageHeader, Progress, Skeleton, useToast, burst, tap } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, type Arena } from "@/lib/api";

const SEG = ["#f2ca7c", "#b495f0", "#8dd6b5", "#f499a7", "#8fb7ff", "#ffb37a", "#d69838", "#8960c5"];

export default function ArenaPage() {
  const r = useRouter(); const toast = useToast(); const { refresh } = useSession();
  const [a, setA] = useState<Arena | null>(null);
  const [rot, setRot] = useState(0);
  const [spinning, setSpinning] = useState(false);
  const [prize, setPrize] = useState<{ label: string; icon: string } | null>(null);
  const [busy, setBusy] = useState("");
  const load = () => get<Arena>("arena").then(setA).catch((e) => toast(e.message, "err"));
  useEffect(() => { load(); }, []); // eslint-disable-line react-hooks/exhaustive-deps

  const spin = async () => {
    if (!a || spinning) return; setSpinning(true); setPrize(null); tap("heavy");
    try {
      const d = await post<{ index: number; prize: { label: string; icon: string; coins: number; xp: number } }>("arena?action=spin", {});
      const n = a.wheel.prizes.length; const seg = 360 / n;
      // چرخ ساعت‌گرد؛ اشاره‌گر بالا — قطعهٔ index را زیر اشاره‌گر بیاور
      const target = 360 * 5 + (360 - (d.index * seg + seg / 2));
      setRot((x) => x + target - (x % 360));
      setTimeout(() => { setPrize(d.prize); setSpinning(false); burst(); tap("success"); refresh(); load(); }, 4300);
    } catch (e) { setSpinning(false); toast(e instanceof Error ? e.message : "خطا", "err"); }
  };
  const claim = async (id: string) => { setBusy(id); try { const d = await post<{ coins: number; xp: number }>("arena?action=claim", { id }); toast(`+${fa(d.coins)} سکه و +${fa(d.xp)} امتیاز 🎉`, "ok"); refresh(); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };

  if (!a) return <div><PageHeader title="مرکز پاداش" back={() => r.back()} /><div className="px-4 space-y-3"><Skeleton className="h-[300px]" /><Skeleton className="h-[200px]" /></div></div>;
  const n = a.wheel.prizes.length, seg = 360 / n;
  const grad = `conic-gradient(${a.wheel.prizes.map((_, i) => `${SEG[i % SEG.length]} ${i * seg}deg ${(i + 1) * seg}deg`).join(",")})`;
  return (
    <div>
      <PageHeader title="مرکز پاداش" sub={`رتبهٔ کلی تو: #${fa(a.rank)} · سطح ${fa(a.level.level)}`} back={() => r.back()} />
      <div className="px-4 space-y-5">
        {/* چرخ شانس */}
        <Card className="card-hero text-center overflow-hidden anim-pop">
          <h2 className="font-black text-[16px] flex items-center justify-center gap-2"><Icon name="wheel" size={20} className="text-[var(--gold)]" />چرخ شانس روزانه</h2>
          <div className="relative w-[260px] h-[260px] mx-auto mt-4">
            <div className="absolute left-1/2 -top-2 -translate-x-1/2 z-10 text-[28px] drop-shadow-lg">🔻</div>
            <div className="wheel w-full h-full rounded-full border-[6px] border-[#f2ca7c] shadow-[0_0_40px_-5px_#f2ca7c88]" style={{ background: grad, transform: `rotate(${rot}deg)` }}>
              {a.wheel.prizes.map((p, i) => <span key={i} className="absolute left-1/2 top-1/2 text-[22px]" style={{ transform: `rotate(${i * seg + seg / 2}deg) translateY(-96px) rotate(${-(i * seg + seg / 2)}deg) translate(-50%,-50%)` }}>{p.icon}</span>)}
            </div>
            <div className="absolute inset-0 m-auto w-16 h-16 rounded-full logo-tile grid place-items-center text-[#2a1d12] shadow-xl"><Icon name="bolt" size={30} /></div>
          </div>
          {prize ? <div className="mt-4 anim-pop text-[18px] font-black text-[var(--gold)]">{prize.icon} {prize.label} برنده شدی!</div> : null}
          <Btn className="mt-4" size="lg" block icon="spark" loading={spinning} disabled={!a.wheel.canSpin} onClick={spin}>{a.wheel.canSpin ? "بچرخان!" : "فردا دوباره بیا 🎡"}</Btn>
        </Card>

        {/* ماموریت‌ها */}
        <section>
          <h2 className="font-black text-[16px] mb-2 flex items-center gap-2"><Icon name="target" size={20} className="text-[var(--purple)]" />ماموریت‌های امروز</h2>
          <div className="space-y-2 stagger">
            {a.quests.map((q) => (
              <Card key={q.id} className={`!p-3 flex items-center gap-3 ${q.ready && !q.claimed ? "border-[var(--green)]/60" : ""}`}>
                <span className="w-11 h-11 rounded-2xl bg-[#ffffff0a] grid place-items-center text-[22px]">{q.icon}</span>
                <div className="flex-1 min-w-0"><b className="block text-[13px]">{q.title}</b><div className="flex items-center gap-2 mt-1.5"><Progress value={q.progress} max={q.target} color={q.ready ? "var(--green)" : "var(--purple)"} h={6} /><span className="text-[10px] text-[var(--muted)] shrink-0">{fa(q.progress)}/{fa(q.target)}</span></div><span className="text-[10px] text-[var(--gold)]">+{fa(q.coins)} سکه · +{fa(q.xp)} امتیاز</span></div>
                {q.claimed ? <span className="text-[var(--green)]"><Icon name="check" size={22} /></span> : <Btn size="sm" variant={q.ready ? "green" : "ghost"} disabled={!q.ready} loading={busy === q.id} onClick={() => claim(q.id)}>{q.ready ? "دریافت" : "…"}</Btn>}
              </Card>
            ))}
          </div>
        </section>

        {/* تالار هفته */}
        <section>
          <div className="flex items-center justify-between mb-2"><h2 className="font-black text-[16px] flex items-center gap-2"><Icon name="crown" size={20} className="text-[var(--gold)]" />برترین‌های هفته</h2><button className="text-[12px] text-[var(--purple)] font-bold press" onClick={() => r.push("/leaderboard")}>کامل ←</button></div>
          <Card className="!p-2 space-y-1">
            {a.hall.map((h) => <div key={h.id} className="flex items-center gap-3 p-2 rounded-xl hover:bg-[#ffffff08]"><span className="w-6 text-center font-black text-[12px] text-[var(--muted)]">{fa(h.rank)}</span><Avatar a={h.avatar} name={h.name} size={36} /><b className="flex-1 text-[13px] truncate">{h.name}</b><span className="text-[12px] text-[var(--gold)] font-bold">{fa(h.weekXp)} XP</span></div>)}
          </Card>
        </section>
        <section>
          <h2 className="font-black text-[16px] mb-2 flex items-center gap-2"><Icon name="shield" size={20} className="text-[var(--purple)]" />قبیله‌های برتر</h2>
          <div className="grid grid-cols-3 gap-2 stagger">{a.tribes.map((t) => <Card key={t.id} className="!p-3 text-center" onClick={() => r.push(`/tribes/detail?id=${t.id}`)}><span className="text-[28px]">{t.emoji}</span><b className="block text-[12px] mt-1 truncate">{t.name}</b><span className="text-[11px] text-[var(--gold)]">{fa(t.xp)}</span></Card>)}</div>
        </section>
      </div>
    </div>
  );
}
