"use client";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { Avatar, Btn, Card, Chip, Empty, PageHeader, Skeleton, useToast } from "@/components/ui";
import { get, post, fa, type Tribe, type TribeMember } from "@/lib/api";

function TribeDetailInner() {
  const id = useSearchParams().get("id") || ""; const r = useRouter(); const toast = useToast();
  const [t, setT] = useState<Tribe | null>(null);
  const [members, setMembers] = useState<TribeMember[] | null>(null);
  const [busy, setBusy] = useState(false);
  const load = () => { get<Tribe>(`tribes/${id}`).then(setT).catch(() => r.replace("/tribes")); get<TribeMember[]>(`tribes/${id}?action=members`).then(setMembers).catch(() => setMembers([])); };
  useEffect(load, [id]); // eslint-disable-line react-hooks/exhaustive-deps
  const join = async () => { setBusy(true); try { let code = ""; if (t && !t.isPublic) code = prompt("کد دعوت:") || ""; const d = await post<{ message: string }>(`tribes/${id}?action=join`, code ? { code } : {}); toast(d.message, "ok"); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(false); } };
  if (!t) return <div><PageHeader title="قبیله" back={() => r.back()} /><div className="px-4"><Skeleton className="h-[200px]" /></div></div>;
  return (
    <div>
      <PageHeader title={t.name} sub={t.motto} back={() => r.back()} />
      <div className="px-4 space-y-4">
        <Card className="card-hero text-center anim-pop" glow={t.logoColor}>
          <span className="w-20 h-20 mx-auto rounded-3xl grid place-items-center text-[40px]" style={{ background: `color-mix(in srgb, ${t.logoColor} 30%, #241b30)` }}>{t.logoEmoji}</span>
          <div className="flex items-center justify-center gap-2 mt-3"><b className="text-[20px]">{t.name}</b><Chip color={t.logoColor}>{t.tag}</Chip></div>
          {t.description ? <p className="text-[13px] text-[var(--muted)] mt-1 leading-6">{t.description}</p> : null}
          <div className="grid grid-cols-4 gap-2 mt-4">{[["امتیاز", t.xp, "var(--purple)"], ["رتبه‌بندی", t.rating, "var(--gold)"], ["برد", t.wins, "var(--green)"], ["باخت", t.losses, "var(--red)"]].map(([l, v, c]) => <div key={String(l)} className="rounded-xl bg-[#ffffff0a] py-2"><b className="block text-[15px]" style={{ color: String(c) }}>{fa(Number(v))}</b><span className="text-[10px] text-[var(--muted)]">{l}</span></div>)}</div>
          {!t.isMember ? <Btn className="mt-4" block variant="purple" icon="shield" loading={busy} onClick={join}>{t.isPublic ? "پیوستن به قبیله" : "پیوستن با کد دعوت"}</Btn> : <Chip color="var(--green)" className="mt-4">تو عضو این قبیله‌ای</Chip>}
        </Card>
        <section>
          <h3 className="font-black text-[15px] mb-2">اعضا ({fa(t.memberCount)}/{fa(t.maxMembers)})</h3>
          {members === null ? <Skeleton className="h-[200px]" /> : members.length === 0 ? <Empty title="عضوی نیست" /> : (
            <div className="space-y-2 stagger">{members.sort((a, b) => b.contributedXp - a.contributedXp).map((m, i) => (
              <Card key={m.id} className="!p-3 flex items-center gap-3" onClick={() => r.push(`/messages/chat?id=${m.id}`)}>
                <span className="w-6 text-center text-[12px] font-black text-[var(--muted)]">{fa(i + 1)}</span>
                <Avatar a={m.avatar} name={m.name} size={42} online={m.online} ring={m.role === "owner" ? "var(--gold)" : undefined} />
                <div className="flex-1 min-w-0"><b className="block text-[14px] truncate">{m.name}</b><span className="text-[11px] text-[var(--muted)]">سطح {fa(m.level)} · {fa(m.contributedXp)} امتیاز برای قبیله</span></div>
                <Chip color={m.role === "owner" ? "var(--gold)" : m.role === "admin" ? "var(--purple)" : "var(--muted)"}>{m.role === "owner" ? "مالک" : m.role === "admin" ? "مدیر" : "عضو"}</Chip>
              </Card>
            ))}</div>
          )}
        </section>
      </div>
    </div>
  );
}
export default function TribeDetail() { return <Suspense fallback={null}><TribeDetailInner /></Suspense>; }
