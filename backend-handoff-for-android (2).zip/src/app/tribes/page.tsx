"use client";
import { useCallback, useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, Empty, Input, PageHeader, Sheet, Skeleton, useToast, burst } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, type Tribe, type TribeMember } from "@/lib/api";

const EMOJIS = ["🛡️", "🦁", "⚡", "🐺", "🔥", "🐚", "🦅", "⚔️", "🌊", "🏹", "🐉", "💎"];
const COLORS = ["#a98cf7", "#f2ca7c", "#8dd6b5", "#f499a7", "#8fb7ff", "#ffb37a"];

export default function Tribes() {
  const r = useRouter(); const toast = useToast(); const { user, refresh } = useSession();
  const [mine, setMine] = useState<{ tribe: Tribe | null; members?: TribeMember[] } | null>(null);
  const [list, setList] = useState<Tribe[] | null>(null);
  const [q, setQ] = useState("");
  const [create, setCreate] = useState(false);
  const [form, setForm] = useState({ name: "", tag: "", motto: "", logoEmoji: "🛡️", logoColor: "#a98cf7", isPublic: true });
  const [busy, setBusy] = useState("");

  const load = useCallback(() => { get<{ tribe: Tribe | null; members?: TribeMember[] }>("tribes?mine=1").then(setMine).catch(() => setMine({ tribe: null })); get<Tribe[]>(`tribes${q ? `?q=${encodeURIComponent(q)}` : ""}`).then(setList).catch(() => setList([])); }, [q]);
  useEffect(() => { const t = setTimeout(load, q ? 350 : 0); return () => clearTimeout(t); }, [load, q]);

  const join = async (t: Tribe) => { setBusy(t.id); try { let code = ""; if (!t.isPublic) code = prompt("کد دعوت قبیله را وارد کن:") || ""; const d = await post<{ message: string }>(`tribes/${t.id}?action=join`, code ? { code } : {}); toast(d.message, "ok"); burst(); load(); refresh(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };
  const leave = async () => { if (!mine?.tribe || !confirm("از قبیله خارج می‌شوی؟")) return; setBusy("leave"); try { const d = await post<{ message: string }>(`tribes/${mine.tribe.id}?action=leave`, {}); toast(d.message); load(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };
  const submit = async () => { setBusy("create"); try { const d = await post<{ message?: string }>("tribes", form); toast(d.message || "قبیله ساخته شد! 🎉", "ok"); burst(); setCreate(false); load(); refresh(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };

  const T = mine?.tribe;
  return (
    <div>
      <PageHeader title="قبیله‌ها" sub="با هم قوی‌تریم — مشترک با سایت" back={() => r.back()} right={!T ? <Btn size="sm" icon="plus" onClick={() => setCreate(true)}>ساخت</Btn> : null} />
      <div className="px-4 space-y-4">
        {mine === null ? <Skeleton className="h-[180px]" /> : T ? (
          <Card className="card-hero relative overflow-hidden anim-pop" glow={T.logoColor}>
            <div className="absolute -left-10 -top-10 w-40 h-40 rounded-full opacity-15" style={{ background: T.logoColor }} />
            <div className="flex items-center gap-3">
              <span className="w-16 h-16 rounded-3xl grid place-items-center text-[34px] shadow-lg" style={{ background: `color-mix(in srgb, ${T.logoColor} 30%, #241b30)` }}>{T.logoEmoji}</span>
              <div className="flex-1 min-w-0"><div className="flex items-center gap-2"><b className="text-[18px] truncate">{T.name}</b><Chip color={T.logoColor}>{T.tag}</Chip></div><p className="text-[12px] text-[var(--muted)] mt-0.5">{T.motto}</p><span className="text-[11px] text-[var(--gold)]">نقش تو: {T.myRole === "owner" ? "مالک" : T.myRole === "admin" ? "مدیر" : "عضو"}</span></div>
            </div>
            <div className="grid grid-cols-4 gap-2 mt-4 text-center">{[["امتیاز", T.xp, "var(--purple)"], ["برد", T.wins, "var(--green)"], ["باخت", T.losses, "var(--red)"], ["عضو", `${fa(T.memberCount)}/${fa(T.maxMembers)}`, "var(--gold)"]].map(([l, v, c]) => <div key={String(l)} className="rounded-xl bg-[#ffffff0a] py-2"><b className="block text-[15px]" style={{ color: String(c) }}>{typeof v === "number" ? fa(v) : v}</b><span className="text-[10px] text-[var(--muted)]">{l}</span></div>)}</div>
            <div className="mt-4">
              <h4 className="text-[12px] font-bold text-[var(--muted)] mb-2">اعضا</h4>
              <div className="hscroll">{(mine.members || []).map((m) => <button key={m.id} onClick={() => r.push(`/messages/chat?id=${m.id}`)} className="press flex flex-col items-center gap-1 w-[60px]"><Avatar a={m.avatar} name={m.name} size={46} online={m.online} ring={m.role === "owner" ? "var(--gold)" : undefined} /><span className="text-[10px] truncate w-full text-center">{m.name}</span></button>)}</div>
            </div>
            <div className="flex gap-2 mt-4"><Btn block variant="soft" icon="users" onClick={() => r.push(`/tribes/detail?id=${T.id}`)}>جزئیات</Btn><Btn block variant="ghost" icon="logout" loading={busy === "leave"} onClick={leave}>خروج</Btn></div>
          </Card>
        ) : (
          <Card className="text-center !py-6 anim-pop"><div className="text-4xl">🛡️</div><b className="block mt-2">هنوز عضو قبیله‌ای نیستی</b><p className="text-[12px] text-[var(--muted)] mt-1">به یکی از قبیله‌ها بپیوند یا قبیلهٔ خودت را بساز (+۲۰۰ امتیاز، +۱۰۰ سکه)</p><Btn className="mt-3" icon="plus" onClick={() => setCreate(true)}>ساخت قبیله</Btn></Card>
        )}

        <label className="flex items-center gap-2 h-12 px-4 rounded-2xl bg-[var(--panel)] border border-[var(--line)]"><Icon name="search" size={18} className="text-[var(--muted)]" /><input value={q} onChange={(e) => setQ(e.target.value)} placeholder="جست‌وجوی نام یا تگ قبیله…" className="flex-1 bg-transparent outline-none text-[14px]" /></label>
        {list === null ? [1, 2, 3].map((i) => <Skeleton key={i} className="h-[84px]" />) : list.length === 0 ? <Empty icon="shield" title="قبیله‌ای پیدا نشد" /> : (
          <div className="space-y-2 stagger">
            {list.map((t, i) => (
              <Card key={t.id} className="!p-3 flex items-center gap-3" onClick={() => r.push(`/tribes/detail?id=${t.id}`)}>
                <span className="w-7 text-center font-black text-[13px] text-[var(--muted)]">{fa(i + 1)}</span>
                <span className="w-12 h-12 rounded-2xl grid place-items-center text-[24px]" style={{ background: `color-mix(in srgb, ${t.logoColor} 25%, transparent)` }}>{t.logoEmoji}</span>
                <div className="flex-1 min-w-0"><div className="flex items-center gap-1.5"><b className="text-[14px] truncate">{t.name}</b>{!t.isPublic ? <Icon name="key" size={13} className="text-[var(--muted)]" /> : null}</div><span className="text-[11px] text-[var(--muted)]">{fa(t.memberCount)} عضو · {fa(t.xp)} امتیاز · {fa(t.wins)} برد</span></div>
                {t.isMember ? <Chip color="var(--green)">عضو</Chip> : !T ? <Btn size="sm" variant="purple" loading={busy === t.id} onClick={() => join(t)}>پیوستن</Btn> : T.id !== t.id && user ? <Btn size="sm" variant="danger" icon="swords" onClick={async () => { try { const d = await post<{ message: string }>(`tribes/${T.id}?action=challenge`, { enemyId: t.id, category: "general" }); toast(d.message, "ok"); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } }}>نبرد</Btn> : null}
              </Card>
            ))}
          </div>
        )}
      </div>

      <Sheet open={create} onClose={() => setCreate(false)} title="ساخت قبیلهٔ جدید">
        <div className="space-y-3 pb-4">
          <div className="flex items-center gap-3"><span className="w-16 h-16 rounded-3xl grid place-items-center text-[32px]" style={{ background: `color-mix(in srgb, ${form.logoColor} 30%, #241b30)` }}>{form.logoEmoji}</span><div className="flex-1 flex flex-wrap gap-1.5">{EMOJIS.map((e) => <button key={e} onClick={() => setForm({ ...form, logoEmoji: e })} className={`press w-9 h-9 rounded-xl text-[18px] ${form.logoEmoji === e ? "bg-[var(--purple)]/30" : "bg-[#ffffff0a]"}`}>{e}</button>)}</div></div>
          <div className="flex gap-2">{COLORS.map((c) => <button key={c} onClick={() => setForm({ ...form, logoColor: c })} className={`press w-8 h-8 rounded-full ${form.logoColor === c ? "ring-2 ring-white" : ""}`} style={{ background: c }} />)}</div>
          <Input label="نام قبیله (حداقل ۳ حرف)" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={30} />
          <div className="grid grid-cols-2 gap-2"><Input label="تگ (تا ۸ حرف)" value={form.tag} onChange={(e) => setForm({ ...form, tag: e.target.value })} maxLength={8} /><Input label="شعار" value={form.motto} onChange={(e) => setForm({ ...form, motto: e.target.value })} maxLength={120} /></div>
          <label className="flex items-center justify-between card !p-3"><span className="text-[13px] font-bold">قبیلهٔ عمومی (بدون کد دعوت)</span><input type="checkbox" checked={form.isPublic} onChange={(e) => setForm({ ...form, isPublic: e.target.checked })} className="w-5 h-5 accent-[var(--purple)]" /></label>
          <Btn block size="lg" icon="shield" loading={busy === "create"} disabled={form.name.trim().length < 3} onClick={submit}>ساخت قبیله</Btn>
        </div>
      </Sheet>
    </div>
  );
}
