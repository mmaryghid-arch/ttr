"use client";
import { useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Btn, Card, Input, useToast } from "@/components/ui";
import { useSession } from "@/components/Session";
import { post, token } from "@/lib/api";

/** ورود با نام‌کاربری/رمز — POST /api/account {action:"login"} → serverToken */
export default function Login() {
  const r = useRouter(); const toast = useToast(); const { refresh } = useSession();
  const [f, setF] = useState({ identifier: "", password: "" });
  const [busy, setBusy] = useState(false);
  const submit = async () => {
    setBusy(true);
    try { const d = await post<{ ok: boolean; serverToken: string }>("account", { action: "login", ...f }); token.set(d.serverToken); await refresh(); toast("خوش آمدی! ✅", "ok"); r.replace("/"); }
    catch (e) { toast(e instanceof Error ? e.message : "ورود ناموفق", "err"); }
    finally { setBusy(false); }
  };
  return (
    <div className="min-h-dvh flex flex-col px-5 pt-[calc(env(safe-area-inset-top)+16px)] pb-8">
      <button onClick={() => r.back()} className="press w-10 h-10 rounded-2xl bg-[var(--panel2)] border border-[var(--line)] grid place-items-center"><Icon name="back" size={18} /></button>
      <div className="text-center mt-8 anim-pop">
        <div className="w-20 h-20 mx-auto rounded-[26px] logo-tile grid place-items-center text-[#2a1d12] anim-float"><Icon name="bolt" size={40} /></div>
        <h1 className="text-[24px] font-black mt-4">ورود به حساب</h1>
        <p className="text-[13px] text-[var(--muted)] mt-1">با همان حساب سایت bu.gamifi.ir وارد شو</p>
      </div>
      <Card className="mt-8 space-y-3 anim-pop">
        <Input label="نام کاربری / ایمیل / موبایل" dir="ltr" autoCapitalize="none" value={f.identifier} onChange={(e) => setF({ ...f, identifier: e.target.value })} />
        <Input label="رمز عبور" type="password" dir="ltr" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} onKeyDown={(e) => e.key === "Enter" && submit()} />
        <Btn block size="lg" icon="login" loading={busy} disabled={!f.identifier || !f.password} onClick={submit}>ورود</Btn>
      </Card>
      <p className="text-center text-[12px] text-[var(--muted)] mt-6 leading-6">حساب نداری؟ به‌صورت میهمان بازی کن و از «پروفایل ← حسابت را دائمی کن» نام‌کاربری بساز.<br />فراموشی رمز: با مدیر تماس بگیر.</p>
      <p className="text-center text-[11px] text-[var(--muted)]/70 mt-auto">حساب آزمایشی (حالت نمایشی): tester / 1234</p>
    </div>
  );
}
