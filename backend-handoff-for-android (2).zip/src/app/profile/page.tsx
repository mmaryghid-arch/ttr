"use client";
import { Suspense, useEffect, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, Empty, Input, PageHeader, Progress, Sheet, Skeleton, Stat, useToast, tap } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, ago, levelOf, avatarUrl, type User } from "@/lib/api";

type Ach = { id: string; title: string; description: string; icon: string; xpReward: number; coinReward: number; unlocked: boolean };
type Notif = { id: string; title: string; body: string; link: string; createdAt: number; seen: number };
type Account = { identifiers: { identifier: string; kind: string }[]; hasPassword: boolean; pushEnabled: boolean };
const SHOP = [{ id: "title-mentor", n: "لقب «مربی»", p: 300, i: "🎓" }, { id: "title-safety", n: "لقب «قهرمان ایمنی»", p: 250, i: "🦺" }, { id: "extra-life", n: "جان اضافه", p: 120, i: "❤️" }, { id: "frame-gold", n: "قاب طلایی", p: 400, i: "🖼️" }, { id: "theme-night", n: "تم شب", p: 200, i: "🌙" }, { id: "badge-fire", n: "نشان آتشین", p: 150, i: "🔥" }];

function ProfileInner() {
  const r = useRouter(); const sp = useSearchParams(); const toast = useToast(); const { user, setUser, logout, refresh } = useSession();
  const [tab, setTab] = useState<"stats" | "ach" | "notifs" | "shop">((sp.get("tab") as "notifs" | null) || "stats");
  const [ach, setAch] = useState<Ach[] | null>(null);
  const [notifs, setNotifs] = useState<Notif[] | null>(null);
  const [acc, setAcc] = useState<Account | null>(null);
  const [edit, setEdit] = useState(false);
  const [upgrade, setUpgrade] = useState(false);
  const [form, setForm] = useState({ name: "", bio: "", img: 1 });
  const [auth, setAuth] = useState({ username: "", password: "", currentPassword: "", email: "", phone: "", name: "" });
  const [busy, setBusy] = useState("");
  const [hist, setHist] = useState<{ id: string; at: number; won: boolean; draw: boolean; opp: { name: string; score: number }; me: { score: number } }[] | null>(null);

  useEffect(() => { get<Ach[]>("daily?kind=achievements").then(setAch).catch(() => setAch([])); get<Notif[]>("daily?kind=notifications").then(setNotifs).catch(() => setNotifs([])); get<Account>("account").then(setAcc).catch(() => {}); get<typeof hist>("pvp?action=history").then(setHist).catch(() => setHist([])); }, []);
  useEffect(() => { if (user) setForm({ name: user.name, bio: user.bio || "", img: Number((user.avatar as { img?: number })?.img) || 1 }); }, [user]);
  if (!user) return null;

  const save = async () => { setBusy("save"); try { const u = await post<User>("me", { name: form.name, bio: form.bio, avatar: { img: form.img } }); setUser(u); setEdit(false); toast("پروفایل ذخیره شد ✅", "ok"); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };
  const doUpgrade = async () => { setBusy("up"); try { const d = await post<{ reward: number }>("account", { action: "save", ...auth }); toast(d.reward ? `حساب دائمی شد! +${fa(d.reward)} سکه 🎁` : "حساب به‌روز شد ✅", "ok"); setUpgrade(false); refresh(); get<Account>("account").then(setAcc).catch(() => {}); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };
  const buy = async (id: string, p: number) => { if (user.coins < p) return toast("سکهٔ کافی نداری", "err"); setBusy(id); try { const d = await post<{ ok: boolean; coins: number; message?: string }>("coins", { op: "buy", itemId: id }); if (d.ok === false) throw new Error(d.message || "خرید انجام نشد"); toast("خرید انجام شد 🎉", "ok"); refresh(); } catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); } finally { setBusy(""); } };
  const togglePush = async () => { if (!acc) return; const v = !acc.pushEnabled; setAcc({ ...acc, pushEnabled: v }); await post("account", { action: "push", enabled: v }).catch(() => {}); };
  const owned = new Set((user.interests || []).filter((x) => x.startsWith("sh:")).map((x) => x.slice(3)));
  const xp = user.xp || 0, lvl = levelOf(xp);
  const isGuest = user.provider === "guest" && !acc?.hasPassword;

  return (
    <div>
      <PageHeader title="پروفایل" right={<div className="flex gap-2"><Btn size="sm" variant="soft" icon="pen" onClick={() => setEdit(true)}>ویرایش</Btn><Btn size="sm" variant="ghost" icon="logout" onClick={async () => { if (confirm("از حساب خارج می‌شوی؟ (میهمان: پیشرفت تنها با ساخت حساب دائمی حفظ می‌شود)")) await logout(); }}>خروج</Btn></div>} />
      <div className="px-4 space-y-4">
        <Card className="card-hero anim-pop">
          <div className="flex items-center gap-4">
            <Avatar a={user.avatar} name={user.name} size={76} ring="var(--gold)" />
            <div className="flex-1 min-w-0">
              <b className="block text-[20px] truncate">{user.name}</b>
              <span className="text-[12px] text-[var(--muted)] block truncate">{user.bio || "بدون بیو"}</span>
              <div className="flex gap-1.5 mt-2 flex-wrap"><Chip color="var(--gold)">سطح {fa(lvl)}</Chip>{user.role === "admin" ? <Chip color="var(--red)">مدیر</Chip> : null}<Chip color={isGuest ? "var(--orange)" : "var(--green)"}>{isGuest ? "میهمان" : "حساب دائمی"}</Chip></div>
            </div>
          </div>
          <div className="mt-4"><div className="flex justify-between text-[11px] text-[var(--muted)] mb-1"><span>{fa(xp % 250)} / ۲۵۰ تا سطح {fa(lvl + 1)}</span><span>{fa(xp)} XP</span></div><Progress value={xp % 250} max={250} /></div>
          {isGuest ? <button onClick={() => { tap(); setUpgrade(true); }} className="press mt-4 w-full flex items-center gap-3 p-3 rounded-2xl bg-[var(--gold)]/10 border border-[var(--gold)]/40 text-right"><span className="w-10 h-10 rounded-xl logo-tile grid place-items-center text-[#2a1d12]"><Icon name="key" size={20} /></span><span className="flex-1"><b className="block text-[13px]">حسابت را دائمی کن</b><span className="text-[11px] text-[var(--muted)]">نام‌کاربری و رمز بساز تا پیشرفتت روی همهٔ دستگاه‌ها و سایت حفظ شود (+۵۰ سکه)</span></span><Icon name="forward" size={18} /></button> : null}
        </Card>

        <div className="flex p-1 rounded-2xl bg-[var(--panel)] border border-[var(--line)]">{[{ k: "stats", l: "آمار", i: "chart" }, { k: "ach", l: "دستاورد", i: "medal" }, { k: "notifs", l: "اعلان", i: "bell" }, { k: "shop", l: "فروشگاه", i: "coin" }].map((t) => <button key={t.k} onClick={() => setTab(t.k as typeof tab)} className={`press flex-1 h-10 rounded-xl text-[12px] font-bold flex items-center justify-center gap-1 ${tab === t.k ? "btn-purple" : "text-[var(--muted)]"}`}><Icon name={t.i} size={16} />{t.l}</button>)}</div>

        {tab === "stats" ? (
          <div className="space-y-4 anim-pop">
            <div className="grid grid-cols-3 gap-2"><Stat icon="coin" value={fa(user.coins)} label="سکه" /><Stat icon="trophy" value={fa(user.cups)} label="جام" color="var(--green)" /><Stat icon="fire" value={fa(user.streak)} label="روز پیاپی" color="var(--orange)" /><Stat icon="play" value={fa(user.played)} label="بازی" color="var(--purple)" /><Stat icon="crown" value={fa(user.wins)} label="برد" color="var(--gold)" /><Stat icon="target" value={user.played ? `${fa(Math.round((user.wins / user.played) * 100))}٪` : "—"} label="نرخ برد" color="var(--blue)" /></div>
            <Card className="!p-3 flex items-center justify-between"><span className="text-[13px] font-bold flex items-center gap-2"><Icon name="chart" size={18} className="text-[var(--purple)]" />امتیاز رتبه‌بندی (Rating)</span><b className="text-[var(--purple)]">{fa(user.rating)}</b></Card>
            <Card className="!p-3 flex items-center justify-between"><span className="text-[13px] font-bold flex items-center gap-2"><Icon name="bell" size={18} className="text-[var(--gold)]" />اعلان‌های سرور</span><button onClick={togglePush} className={`press w-12 h-7 rounded-full relative transition-colors ${acc?.pushEnabled ? "bg-[var(--green)]" : "bg-[#ffffff20]"}`}><span className={`absolute top-1 w-5 h-5 rounded-full bg-white transition-all ${acc?.pushEnabled ? "right-1" : "right-6"}`} /></button></Card>
            {acc?.identifiers?.length ? <Card className="!p-3"><b className="text-[12px] text-[var(--muted)] block mb-2">شناسه‌های ورود</b>{acc.identifiers.map((i) => <div key={i.identifier} className="flex justify-between text-[13px] py-1"><span>{i.kind === "username" ? "نام کاربری" : i.kind === "email" ? "ایمیل" : "موبایل"}</span><b dir="ltr">{i.identifier}</b></div>)}<Btn size="sm" variant="soft" className="mt-2" icon="key" onClick={() => setUpgrade(true)}>تغییر رمز/اطلاعات</Btn></Card> : null}
            <section><h3 className="font-black text-[14px] mb-2">نبردهای اخیر</h3>{hist === null ? <Skeleton className="h-[100px]" /> : hist.length === 0 ? <Empty icon="swords" title="هنوز نبردی نداشتی" /> : <div className="space-y-2">{hist.slice(0, 10).map((h) => <Card key={h.id} className="!p-3 flex items-center gap-3" onClick={() => r.push(`/pvp/battle?id=${h.id}`)}><span className={`w-10 h-10 rounded-xl grid place-items-center font-black ${h.won ? "bg-[var(--green)]/20 text-[var(--green)]" : h.draw ? "bg-[#ffffff10]" : "bg-[var(--red)]/20 text-[var(--red)]"}`}>{h.won ? "W" : h.draw ? "D" : "L"}</span><div className="flex-1 min-w-0"><b className="block text-[13px] truncate">مقابل {h.opp.name}</b><span className="text-[11px] text-[var(--muted)]">{fa(h.me.score)} – {fa(h.opp.score)} · {ago(h.at)}</span></div><Icon name="forward" size={16} className="text-[var(--muted)]" /></Card>)}</div>}</section>
          </div>
        ) : tab === "ach" ? (
          ach === null ? <Skeleton className="h-[300px]" /> : <div className="grid grid-cols-2 gap-3 stagger">{ach.map((a) => <Card key={a.id} className={`!p-4 text-center ${a.unlocked ? "border-[var(--gold)]/50" : "opacity-60 grayscale"}`}><span className="text-[36px]">{a.icon}</span><b className="block text-[13px] mt-1">{a.title}</b><span className="text-[11px] text-[var(--muted)] block leading-5">{a.description}</span><span className="text-[10px] text-[var(--gold)]">+{fa(a.xpReward)} XP · +{fa(a.coinReward)} سکه</span></Card>)}</div>
        ) : tab === "notifs" ? (
          notifs === null ? <Skeleton className="h-[300px]" /> : notifs.length === 0 ? <Empty icon="bell" title="اعلانی نداری" /> : <div className="space-y-2 stagger">{notifs.map((n) => <Card key={n.id} className={`!p-3 flex gap-3 ${!n.seen ? "border-[var(--gold)]/40" : ""}`} onClick={() => r.push(n.link === "pvp" ? "/pvp" : n.link === "tribe" ? "/tribes" : n.link === "league" || n.link === "event" ? "/compete" : "/")}><span className="w-10 h-10 rounded-xl bg-[var(--gold)]/15 text-[var(--gold)] grid place-items-center shrink-0"><Icon name="bell" size={20} /></span><div className="flex-1 min-w-0"><b className="block text-[13px]">{n.title}</b><p className="text-[12px] text-[var(--muted)] leading-5">{n.body}</p><span className="text-[10px] text-[var(--muted)]">{ago(n.createdAt)}</span></div></Card>)}</div>
        ) : (
          <div className="space-y-3 anim-pop"><Card className="!p-3 flex items-center justify-between"><span className="text-[13px]">موجودی</span><b className="text-[var(--gold)] text-[18px] flex items-center gap-1"><Icon name="coin" size={20} />{fa(user.coins)}</b></Card><div className="grid grid-cols-2 gap-3 stagger">{SHOP.map((s) => <Card key={s.id} className="!p-4 text-center"><span className="text-[34px]">{s.i}</span><b className="block text-[13px] mt-1">{s.n}</b>{owned.has(s.id) ? <Chip color="var(--green)" className="mt-2">خریداری شده</Chip> : <Btn size="sm" className="mt-2" icon="coin" loading={busy === s.id} onClick={() => buy(s.id, s.p)}>{fa(s.p)}</Btn>}</Card>)}</div></div>
        )}
      </div>

      <Sheet open={edit} onClose={() => setEdit(false)} title="ویرایش پروفایل">
        <div className="space-y-3 pb-4">
          <div className="grid grid-cols-5 gap-2">{Array.from({ length: 20 }, (_, i) => i + 1).map((i) => <button key={i} onClick={() => setForm({ ...form, img: i })} className={`press rounded-full p-0.5 ${form.img === i ? "ring-2 ring-[var(--gold)]" : ""}`}>{/* eslint-disable-next-line @next/next/no-img-element */}<img src={avatarUrl({ img: i })} alt="" className="w-full aspect-square rounded-full object-cover bg-[var(--panel2)]" /></button>)}</div>
          <Input label="نام نمایشی" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} maxLength={40} />
          <Input label="بیو" value={form.bio} onChange={(e) => setForm({ ...form, bio: e.target.value })} maxLength={300} />
          <Btn block size="lg" icon="check" loading={busy === "save"} onClick={save}>ذخیره</Btn>
        </div>
      </Sheet>
      <Sheet open={upgrade} onClose={() => setUpgrade(false)} title={acc?.hasPassword ? "تغییر اطلاعات حساب" : "ساخت حساب دائمی"}>
        <div className="space-y-3 pb-4">
          <p className="text-[12px] text-[var(--muted)] leading-6">با همین نام‌کاربری و رمز می‌توانی در سایت bu.gamifi.ir هم وارد شوی. ثبت ایمیل یا موبایل ۵۰ سکه پاداش دارد.</p>
          <Input label="نام کاربری (حداقل ۳ نویسه)" dir="ltr" value={auth.username} onChange={(e) => setAuth({ ...auth, username: e.target.value })} />
          <Input label={acc?.hasPassword ? "رمز جدید" : "رمز عبور (حداقل ۴ نویسه)"} type="password" dir="ltr" value={auth.password} onChange={(e) => setAuth({ ...auth, password: e.target.value })} />
          {acc?.hasPassword ? <Input label="رمز فعلی" type="password" dir="ltr" value={auth.currentPassword} onChange={(e) => setAuth({ ...auth, currentPassword: e.target.value })} /> : null}
          <div className="grid grid-cols-2 gap-2"><Input label="ایمیل (اختیاری)" dir="ltr" value={auth.email} onChange={(e) => setAuth({ ...auth, email: e.target.value })} /><Input label="موبایل (اختیاری)" dir="ltr" value={auth.phone} onChange={(e) => setAuth({ ...auth, phone: e.target.value })} /></div>
          <Btn block size="lg" icon="key" loading={busy === "up"} disabled={auth.username.trim().length < 3 || auth.password.length < 4} onClick={doUpgrade}>ثبت</Btn>
          <button className="w-full text-center text-[12px] text-[var(--purple)] font-bold press py-2" onClick={() => { setUpgrade(false); r.push("/login"); }}>قبلاً حساب داری؟ وارد شو</button>
        </div>
      </Sheet>
    </div>
  );
}
export default function Profile() { return <Suspense fallback={null}><ProfileInner /></Suspense>; }
