import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { SessionProvider } from "@/components/Session";
import { ToastProvider } from "@/components/ui";
import AppShell from "@/components/AppShell";

export const metadata: Metadata = {
  title: "گیمیفای ۲ | اپ اندروید",
  description: "رقابت کن، تجربه بساز و هر روز چیز تازه‌ای یاد بگیر. مسابقه، قبیله، نبرد دونفره و پاداش روزانه.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, statusBarStyle: "black-translucent", title: "گیمیفای ۲" },
};
export const viewport: Viewport = { themeColor: "#17111f", width: "device-width", initialScale: 1, maximumScale: 1, userScalable: false, viewportFit: "cover" };

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fa" dir="rtl">
      <body>
        <ToastProvider>
          <SessionProvider>
            <AppShell>{children}</AppShell>
          </SessionProvider>
        </ToastProvider>
      </body>
    </html>
  );
}
