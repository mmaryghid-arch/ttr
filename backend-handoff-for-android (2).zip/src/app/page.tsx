"use client";
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Icon from "@/components/Icon";
import { Avatar, Btn, Card, Chip, IconBtn, Progress, Sheet, Skeleton, useToast, tap, burst } from "@/components/ui";
import { useSession } from "@/components/Session";
import { get, post, fa, levelOf, catIcon, type Category, type Story, type Contact } from "@/lib/api";

export default function Home() {
  const r = useRouter();
  const { user, config, setUser, refresh } = useSession();
  const toast = useToast();
  const [cats, setCats] = useState<Category[] | null>(null);
  const [stories, setStories] = useState<Story[] | null>(null);
  const [daily, setDaily] = useState<{ claimed: boolean; streak: number } | null>(null);
  const [unread, setUnread] = useState(0);
  const [notif, setNotif] = useState(0);
  const [story, setStory] = useState<Story | null>(null);
  const [pick, setPick] = useState<number | null>(null);
  const [res, setRes] = useState<{ correct: number; explanation: string } | null>(null);
  const [claiming, setClaiming] = useState(false);

  useEffect(() => {
    get<Category[]>("questions?category=_categories").then(setCats).catch(() => setCats([]));
    get<{ stories: Story[] }>("stories").then((d) => setStories(d.stories)).catch(() => setStories([]));
    get<{ claimed: boolean; streak: number }>("daily").then(setDaily).catch(() => {});
    get<Contact[]>("messages?scan=1").then((c) => setUnread(c.reduce((s, x) => s + x.unread, 0))).catch(() => {});
    get<{ seen: number }[]>("daily?kind=notifications").then((n) => setNotif(n.filter((x) => !x.seen).length)).catch(() => {});
  }, []);

  const claim = async () => {
    setClaiming(true);
    try { const d = await post<{ message: string; balance: number; streak: number }>("daily", {}); toast(d.message, "ok"); setDaily({ claimed: true, streak: d.streak }); if (user) setUser({ ...user, coins: d.balance, streak: d.streak }); burst(); }
    catch (e) { toast(e instanceof Error ? e.message : "خطا", "err"); setDaily((d) => d && { ...d, claimed: true }); }
    finally { setClaiming(false); }
  };
  const openStory = async (s: Story) => { setStory(s); setPick(null); setRes(null); tap("medium"); if (!s.options?.length) { post("stories", { id: s.id }).catch(() => {}); setStories((l) => l && l.map((x) => (x.id === s.id ? { ...x, seen: true } : x))); } };
  const answerStory = async (i: number) => { if (!story || pick !== null) return; setPick(i); try { const d = await post<{ correct: number; explanation: string }>("stories", { id: story.id, answer: i }); setRes(d); tap(d.correct === i ? "success" : "error"); setStories((l) => l && l.map((x) => (x.id === story.id ? { ...x, seen: true } : x))); } catch { toast("استوری منقضی شده", "err"); } };

  if (!user) return null;
  const xp = user.xp || 0, lvl = levelOf(xp);
  const broadcasts = config?.broadcasts || [];

  return (
    <div className="px-4 pt-[calc(env(safe-area-inset-top)+12px)] space-y-5">
      {/* سربرگ */}
      <header className="flex items-center gap-3 anim-drop">
        <button className="press" onClick={() => r.push("/profile")}><Avatar a={user.avatar} name={user.name} size={50} ring="var(--gold)" /></button>
        <div className="flex-1 min-w-0">
          <div className="text-[12px] text-[var(--muted)]">خوش آمدی 👋</div>
          <div className="font-black text-[17px] truncate">{user.name}</div>
        </div>
        <IconBtn icon="chat" badge={unread} onClick={() => r.push("/messages")} aria-label="پیام‌ها" />
        <IconBtn icon="bell" badge={notif} onClick={() => r.push("/profile?tab=notifs")} aria-label="اعلان‌ها" />
      </header>

      {/* کارت سطح و دارایی */}
      <Card className="card-hero anim-pop">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-2xl logo-tile grid place-items-center text-[#2a1d12] font-black text-[18px] shadow-lg">{fa(lvl)}</div>
          <div className="flex-1">
            <div className="flex justify-between text-[12px] mb-1.5"><b>سطح {fa(lvl)}</b><span className="text-[var(--muted)]">{fa(xp % 250)} / ۲۵۰ XP</span></div>
            <Progress value={xp % 250} max={250} />
          </div>
        </div>
        <div className="grid grid-cols-4 gap-2 mt-4 text-center">
          {[{ i: "coin", v: user.coins, l: "سکه", c: "var(--gold)" }, { i: "star", v: user.xp, l: "امتیاز", c: "var(--purple)" }, { i: "trophy", v: user.cups, l: "جام", c: "var(--green)" }, { i: "fire", v: user.streak, l: "روز پیاپی", c: "var(--orange)" }].map((s) => (
            <div key={s.l} className="rounded-2xl bg-[#ffffff0a] py-2.5">
              <div className="flex items-center justify-center gap-1 font-black text-[15px]" style={{ color: s.c }}><Icon name={s.i} size={16} />{fa(s.v)}</div>
              <div className="text-[10px] text-[var(--muted)] mt-0.5">{s.l}</div>
            </div>
          ))}
        </div>
      </Card>

      {/* استوری‌ها */}
      <section>
        <div className="flex items-center justify-between mb-2"><h2 className="font-black text-[16px]">استوری‌های امروز</h2><button className="text-[12px] text-[var(--purple)] font-bold press" onClick={() => r.push("/feed")}>فید ←</button></div>
        <div className="hscroll">
          <button onClick={() => r.push("/feed?compose=story")} className="press flex flex-col items-center gap-1.5 w-[72px]">
            <span className="w-[64px] h-[64px] rounded-full grid place-items-center border-2 border-dashed border-[var(--purple)] text-[var(--purple)]"><Icon name="plus" size={26} /></span>
            <span className="text-[11px] text-[var(--muted)]">استوری تو</span>
          </button>
          {stories === null ? [1, 2, 3, 4].map((i) => <Skeleton key={i} className="w-[64px] h-[64px] !rounded-full" />) :
            stories.map((s) => (
              <button key={s.id} onClick={() => openStory(s)} className="press flex flex-col items-center gap-1.5 w-[72px]">
                <Avatar a={s.avatar} name={s.author} size={64} ring={s.seen ? "#5a4a6a" : "var(--gold)"} />
                <span className="text-[11px] text-[var(--muted)] truncate w-full text-center">{s.author}</span>
              </button>
            ))}
        </div>
      </section>

      {/* جایزهٔ روزانه + چرخ شانس */}
      <div className="grid grid-cols-2 gap-3 stagger">
        <Card glow="#f2ca7c" className="!p-4 relative overflow-hidden" onClick={daily?.claimed ? undefined : claim}>
          <div className="absolute -left-6 -top-6 w-24 h-24 rounded-full bg-[var(--gold)]/10" />
          <div className={`w-11 h-11 rounded-2xl grid place-items-center text-[#2a1d12] ${daily?.claimed ? "bg-[#ffffff1a] text-[var(--muted)]" : "logo-tile anim-pulse"}`}><Icon name="gift" size={24} /></div>
          <b className="block mt-3 text-[15px]">جایزهٔ روزانه</b>
          <span className="text-[12px] text-[var(--muted)]">{daily?.claimed ? "امروز دریافت شد ✅" : claiming ? "در حال دریافت…" : `+${fa(25 + Math.min(100, ((daily?.streak || 0) + 1) * 5))} سکه آماده!`}</span>
        </Card>
        <Card glow="#b495f0" className="!p-4 relative overflow-hidden" onClick={() => r.push("/arena")}>
          <div className="absolute -left-6 -top-6 w-24 h-24 rounded-full bg-[var(--purple)]/10" />
          <div className="w-11 h-11 rounded-2xl grid place-items-center bg-gradient-to-br from-[var(--purple)] to-[var(--purple2)] text-white"><Icon name="wheel" size={24} /></div>
          <b className="block mt-3 text-[15px]">مرکز پاداش</b>
          <span className="text-[12px] text-[var(--muted)]">ماموریت‌ها و چرخ شانس</span>
        </Card>
      </div>

      {/* اعلان مدیر */}
      {broadcasts.map((b) => (
        <Card key={b.id} className="!p-4 border-[var(--gold)]/40 flex gap-3 items-start anim-pop" onClick={() => r.push(b.link === "league" || b.link === "event" ? "/compete" : b.link === "pvp" ? "/pvp" : "/feed")}>
          <span className="text-[var(--gold)] mt-0.5"><Icon name="bell" size={20} /></span>
          <div className="flex-1 min-w-0"><b className="block text-[14px]">{b.title}</b><p className="text-[12px] text-[var(--muted)] leading-5">{b.body}</p></div>
        </Card>
      ))}

      {/* میان‌برها */}
      <div className="grid grid-cols-4 gap-2 stagger">
        {[{ i: "swords", l: "نبرد زنده", h: "/pvp", c: "var(--red)" }, { i: "shield", l: "قبیله", h: "/tribes", c: "var(--purple)" }, { i: "crown", l: "رتبه‌بندی", h: "/leaderboard", c: "var(--gold)" }, { i: "feed", l: "فید", h: "/feed", c: "var(--green)" }].map((q) => (
          <button key={q.h} onClick={() => { tap(); r.push(q.h); }} className="press flex flex-col items-center gap-1.5 py-3 rounded-2xl bg-[var(--panel)] border border-[var(--line)]">
            <span className="w-10 h-10 rounded-xl grid place-items-center" style={{ background: `color-mix(in srgb, ${q.c} 18%, transparent)`, color: q.c }}><Icon name={q.i} size={22} /></span>
            <span className="text-[11px] font-bold">{q.l}</span>
          </button>
        ))}
      </div>

      {/* دسته‌ها */}
      <section>
        <div className="flex items-center justify-between mb-2"><h2 className="font-black text-[16px]">دسته‌بندی سؤال‌ها</h2><button className="text-[12px] text-[var(--purple)] font-bold press" onClick={() => r.push("/play")}>همه ←</button></div>
        <div className="grid grid-cols-2 gap-3 stagger">
          {cats === null ? [1, 2, 3, 4].map((i) => <Skeleton key={i} className="h-[112px]" />) : cats.filter((c) => c.active !== 0).slice(0, 6).map((c) => (
            <Card key={c.id} className="!p-4 relative overflow-hidden" onClick={() => r.push(`/play?category=${c.id}`)} glow={c.color}>
              <div className="absolute -right-5 -bottom-5 w-24 h-24 rounded-full opacity-20" style={{ background: c.color }} />
              {/* eslint-disable-next-line @next/next/no-img-element */}
              <img src={catIcon(c.id)} alt="" className="w-11 h-11 object-contain" onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
              <b className="block mt-2 text-[14px]">{c.name}</b>
              <span className="text-[11px] text-[var(--muted)] line-clamp-1">{c.subtitle}</span>
              {c.tag ? <Chip color={c.color} className="mt-2 !h-6 !text-[10px]">{c.tag}</Chip> : null}
            </Card>
          ))}
        </div>
      </section>

      {/* نمایش استوری */}
      <Sheet open={!!story} onClose={() => setStory(null)} title={story ? <span className="flex items-center gap-2"><Avatar a={story.avatar} name={story.author} size={30} />{story.author}</span> : null}>
        {story ? (
          <div className="pb-4">
            <div className="rounded-3xl p-6 text-center text-[17px] font-black leading-8 bg-gradient-to-br from-[#3b2850] via-[#6b4f8d] to-[#3b2850] anim-bg-in">{story.title}</div>
            {story.options?.length ? (
              <div className="mt-4 space-y-2">
                {story.options.map((o, i) => (
                  <button key={i} onClick={() => answerStory(i)} style={{ animationDelay: `${i * 0.07}s` }} className={`opt ${pick === i && !res ? "pick" : ""} ${res ? (res.correct === i ? "ok" : pick === i ? "bad" : "") : ""}`}><span className="k">{["الف", "ب", "ج", "د"][i]}</span>{o}</button>
                ))}
                {res ? <p className="text-[13px] text-[var(--muted)] leading-6 pt-2">{res.explanation}</p> : null}
              </div>
            ) : null}
            <div className="flex gap-2 mt-4"><Btn variant="soft" block icon="chat" onClick={() => r.push(`/messages/chat?id=${story.userId}`)}>پیام</Btn><Btn variant="purple" block icon="swords" onClick={() => r.push(`/pvp?invite=${story.userId}`)}>دعوت به نبرد</Btn></div>
          </div>
        ) : null}
      </Sheet>
    </div>
  );
}
