import { NextRequest } from "next/server";
import { mockHandle } from "@/lib/mock-upstream";

/**
 * 🔁 Gateway هم‌مبدأ به بک‌اند اصلی (bu.gamifi.ir)
 * - هیچ منطق/دیتابیسی ندارد؛ فقط درخواست را با هدر `x-gamify-token` عبور می‌دهد.
 * - توکنِ تازه (هدر x-gamify-token / کوکی gtok پاسخ) به کلاینت برگردانده می‌شود.
 * - SSE (/api/events) به‌صورت استریم عبور داده می‌شود.
 * - اگر GAMIFI_MOCK=auto و سرور اصلی در دسترس نبود (مثل سندباکس بدون اینترنت)، یک
 *   شبیه‌ساز قرارداد همان API پاسخ می‌دهد و هدر `x-gamifi-mock: 1` می‌گذارد.
 */
export const dynamic = "force-dynamic";

const UPSTREAM = (process.env.UPSTREAM_API || "https://bu.gamifi.ir").replace(/\/$/, "");
const MOCK = (process.env.GAMIFI_MOCK || "auto").toLowerCase();

function tokenOf(req: NextRequest) {
  return req.headers.get("x-gamify-token") || (req.headers.get("authorization") || "").replace(/^Bearer\s+/i, "") || "";
}

async function forward(req: NextRequest, path: string[]) {
  const url = new URL(req.url);
  const target = `${UPSTREAM}/api/${path.join("/")}${url.search}`;
  const token = tokenOf(req);
  const isSse = path[0] === "events";
  const headers: Record<string, string> = { accept: req.headers.get("accept") || "application/json" };
  if (token) { headers["x-gamify-token"] = token; headers["authorization"] = `Bearer ${token}`; headers["cookie"] = `gtok=${token}; gm_session=${token}`; }
  const ct = req.headers.get("content-type");
  if (ct) headers["content-type"] = ct;
  const body = req.method === "GET" || req.method === "HEAD" ? undefined : await req.arrayBuffer();

  if (MOCK === "on") return mockHandle(req, path, token, body);
  // مدار شکن: اگر سرور اصلی اخیراً در دسترس نبود، تا ۶۰ ثانیه مستقیم به شبیه‌ساز برو (فقط حالت auto)
  const g = globalThis as unknown as { __gwDownUntil?: number };
  if (MOCK === "auto" && (g.__gwDownUntil || 0) > Date.now()) return mockHandle(req, path, token, body);

  let upstream: Response;
  try {
    upstream = await fetch(target, {
      method: req.method, headers, body, redirect: "manual", cache: "no-store",
      signal: isSse ? req.signal : AbortSignal.timeout(Number(process.env.UPSTREAM_TIMEOUT_MS) || 8000),
    });
    g.__gwDownUntil = 0;
  } catch (e) {
    if (MOCK === "auto") { g.__gwDownUntil = Date.now() + 60000; return mockHandle(req, path, token, body); }
    return Response.json({ error: "upstream-unreachable", message: "اتصال به سرور برقرار نشد", detail: e instanceof Error ? e.message : "" }, { status: 502 });
  }

  const out = new Headers();
  out.set("cache-control", "no-store");
  const rct = upstream.headers.get("content-type"); if (rct) out.set("content-type", rct);
  let fresh = upstream.headers.get("x-gamify-token") || "";
  if (!fresh) {
    const sc = upstream.headers.get("set-cookie") || "";
    const m = sc.match(/gtok=([^;,\s]+)/); if (m) fresh = m[1];
  }
  if (fresh) out.set("x-gamify-token", fresh);
  if (isSse) { out.set("x-accel-buffering", "no"); out.set("connection", "keep-alive"); return new Response(upstream.body, { status: upstream.status, headers: out }); }
  const buf = await upstream.arrayBuffer();
  return new Response(buf, { status: upstream.status, headers: out });
}

type Ctx = { params: Promise<{ path: string[] }> };
export async function GET(req: NextRequest, ctx: Ctx) { return forward(req, (await ctx.params).path); }
export async function POST(req: NextRequest, ctx: Ctx) { return forward(req, (await ctx.params).path); }
export async function PUT(req: NextRequest, ctx: Ctx) { return forward(req, (await ctx.params).path); }
export async function DELETE(req: NextRequest, ctx: Ctx) { return forward(req, (await ctx.params).path); }
