"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, type ReactNode } from "react";
import { useRouter } from "next/navigation";
import Icon from "./Icon";
import { Btn, tap } from "./ui";
import { useSession } from "./Session";

const TABS = [
  { href: "/", icon: "home", label: "خانه" },
  { href: "/compete", icon: "trophy", label: "مسابقات" },
  { href: "/play", icon: "play", label: "بازی", big: true },
  { href: "/pvp", icon: "swords", label: "نبرد" },
  { href: "/profile", icon: "user", label: "پروفایل" },
];

export default function AppShell({ children }: { children: ReactNode }) {
  const path = usePathname();
  const router = useRouter();
  const { loading, error, user, refresh, mock } = useSession();
  useEffect(() => {
    let off: (() => void) | undefined;
    import("@capacitor/app").then(({ App }) => App.addListener("backButton", ({ canGoBack }) => { if (window.location.pathname === "/" || window.location.pathname === "/index.html") App.exitApp(); else if (canGoBack) window.history.back(); else router.replace("/"); }).then((h) => { off = () => h.remove(); })).catch(() => {});
    return () => off?.();
  }, [router]);
  const hideTabs = /^\/(play\/match|pvp\/battle|messages\/chat|login)/.test(path);

  if (loading && !user) return (
    <div className="min-h-dvh grid place-items-center bg-[var(--bg)]">
      <div className="text-center anim-pop">
        <div className="w-24 h-24 mx-auto rounded-[28px] logo-tile grid place-items-center text-[#2a1d12] anim-float"><Icon name="bolt" size={48} /></div>
        <h1 className="mt-5 text-[26px] font-black sheen">گیمیفای <span className="text-[var(--gold)]">۲</span></h1>
        <p className="text-[13px] text-[var(--muted)] mt-1">یک بازی، هزار تجربه</p>
        <div className="spinner mx-auto mt-6" />
      </div>
    </div>
  );
  if (error && !user) return (
    <div className="min-h-dvh grid place-items-center p-8 text-center">
      <div>
        <div className="text-5xl mb-3">📡</div>
        <h2 className="text-[18px] font-black mb-1">اتصال به سرور برقرار نشد</h2>
        <p className="text-[13px] text-[var(--muted)] mb-5">{error}</p>
        <Btn icon="refresh" onClick={refresh}>تلاش دوباره</Btn>
      </div>
    </div>
  );

  return (
    <div className="min-h-dvh max-w-[520px] mx-auto relative bg-grid">
      {mock ? <div className="sticky top-0 z-40 text-center text-[11px] font-bold py-1 bg-[#4a3a12] text-[var(--gold)]">حالت نمایشی — سرور bu.gamifi.ir از این شبکه در دسترس نیست؛ داده‌ها شبیه‌سازی‌شده‌اند</div> : null}
      <main key={path} className={`anim-page ${hideTabs ? "" : "pb-[calc(env(safe-area-inset-bottom)+92px)]"}`}>{children}</main>
      {!hideTabs ? (
        <nav className="fixed bottom-0 inset-x-0 z-40 flex justify-center pointer-events-none">
          <div className="pointer-events-auto w-full max-w-[520px] px-3 pb-[calc(env(safe-area-inset-bottom)+10px)]">
            <div className="tabbar flex items-end justify-around h-[68px] rounded-[26px] px-2">
              {TABS.map((t) => {
                const active = t.href === "/" ? path === "/" : path.startsWith(t.href);
                if (t.big) return (
                  <Link key={t.href} href={t.href} onClick={() => tap("medium")} className="press -translate-y-5 w-16 h-16 rounded-full logo-tile grid place-items-center text-[#2a1d12] shadow-[0_12px_30px_-6px_#f2ca7c99] border-4 border-[var(--bg)]" aria-label={t.label}>
                    <Icon name="play" size={30} />
                  </Link>
                );
                return (
                  <Link key={t.href} href={t.href} onClick={() => tap()} className={`press flex flex-col items-center justify-center gap-0.5 w-16 h-full text-[11px] font-bold transition-colors ${active ? "text-[var(--gold)]" : "text-[var(--muted)]"}`}>
                    <span className={`grid place-items-center w-10 h-7 rounded-xl transition-all ${active ? "bg-[var(--gold)]/15" : ""}`}><Icon name={t.icon} size={22} /></span>
                    {t.label}
                  </Link>
                );
              })}
            </div>
          </div>
        </nav>
      ) : null}
    </div>
  );
}
