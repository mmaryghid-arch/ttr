"use client";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ButtonHTMLAttributes, type ReactNode } from "react";
import Icon from "./Icon";
import { avatarUrl, fa } from "@/lib/api";

/* ---------- لرزش لمسی (Capacitor Haptics در اپ؛ Vibration API در وب) ---------- */
export async function tap(kind: "light" | "medium" | "heavy" | "success" | "error" = "light") {
  try {
    const { Haptics, ImpactStyle, NotificationType } = await import("@capacitor/haptics");
    if (kind === "success" || kind === "error") await Haptics.notification({ type: kind === "success" ? NotificationType.Success : NotificationType.Error });
    else await Haptics.impact({ style: kind === "light" ? ImpactStyle.Light : kind === "medium" ? ImpactStyle.Medium : ImpactStyle.Heavy });
  } catch { try { navigator.vibrate?.(kind === "light" ? 8 : kind === "error" ? [30, 40, 30] : 18); } catch { /* ignore */ } }
}

/* ---------- دکمه ---------- */
type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "gold" | "purple" | "ghost" | "danger" | "green" | "soft"; size?: "sm" | "md" | "lg"; icon?: string; loading?: boolean; block?: boolean };
export function Btn({ variant = "gold", size = "md", icon, loading, block, className = "", children, onClick, ...rest }: BtnProps) {
  const v = { gold: "btn-gold", purple: "btn-purple", ghost: "btn-ghost", danger: "btn-danger", green: "btn-green", soft: "btn-soft" }[variant];
  const s = { sm: "h-9 px-3 text-[13px] gap-1.5 rounded-xl", md: "h-12 px-5 text-[15px] gap-2 rounded-2xl", lg: "h-14 px-6 text-[17px] gap-2.5 rounded-2xl" }[size];
  return (
    <button {...rest} disabled={rest.disabled || loading} onClick={(e) => { tap(); onClick?.(e); }} className={`press inline-flex items-center justify-center font-extrabold select-none ${v} ${s} ${block ? "w-full" : ""} ${className}`}>
      {loading ? <span className="spinner" /> : icon ? <Icon name={icon} size={size === "sm" ? 16 : 20} /> : null}
      {children}
    </button>
  );
}

export function IconBtn({ icon, badge, className = "", size = 40, onClick, ...rest }: ButtonHTMLAttributes<HTMLButtonElement> & { icon: string; badge?: number; size?: number }) {
  return (
    <button {...rest} onClick={(e) => { tap(); onClick?.(e); }} style={{ width: size, height: size }} className={`press relative grid place-items-center rounded-2xl bg-[var(--panel2)] border border-[var(--line)] text-[var(--text)] ${className}`}>
      <Icon name={icon} size={Math.round(size * 0.52)} />
      {badge ? <span className="absolute -top-1 -left-1 min-w-5 h-5 px-1 rounded-full bg-[var(--red)] text-[#2a0d14] text-[11px] font-black grid place-items-center">{fa(badge)}</span> : null}
    </button>
  );
}

/* ---------- کارت ---------- */
export function Card({ children, className = "", onClick, glow }: { children: ReactNode; className?: string; onClick?: () => void; glow?: string }) {
  return (
    <div onClick={onClick ? () => { tap(); onClick(); } : undefined} style={glow ? { boxShadow: `0 10px 40px -12px ${glow}66` } : undefined} className={`card ${onClick ? "press cursor-pointer" : ""} ${className}`}>{children}</div>
  );
}

/* ---------- آواتار ---------- */
export function Avatar({ a, name, size = 44, ring, online }: { a: unknown; name?: string; size?: number; ring?: string; online?: boolean }) {
  return (
    <span className="relative inline-block shrink-0" style={{ width: size, height: size }}>
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src={avatarUrl(a, name)} alt={name || ""} width={size} height={size} className="rounded-full object-cover bg-[var(--panel2)]" style={{ width: size, height: size, boxShadow: ring ? `0 0 0 2.5px var(--bg), 0 0 0 5px ${ring}` : undefined }} loading="lazy" />
      {online ? <span className="absolute bottom-0 right-0 w-3 h-3 rounded-full bg-[var(--green)] ring-2 ring-[var(--bg)]" /> : null}
    </span>
  );
}

/* ---------- نوار پیشرفت ---------- */
export function Progress({ value, max, color = "var(--gold)", h = 8 }: { value: number; max: number; color?: string; h?: number }) {
  const pct = Math.max(0, Math.min(100, max ? (value / max) * 100 : 0));
  return <div className="w-full rounded-full bg-[#ffffff14] overflow-hidden" style={{ height: h }}><div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, background: color }} /></div>;
}

/* ---------- چیپ / نشان ---------- */
export function Chip({ children, color = "var(--purple)", className = "" }: { children: ReactNode; color?: string; className?: string }) {
  return <span className={`inline-flex items-center gap-1 px-2.5 h-7 rounded-full text-[12px] font-bold ${className}`} style={{ background: `color-mix(in srgb, ${color} 18%, transparent)`, color }}>{children}</span>;
}
export function Stat({ icon, value, label, color = "var(--gold)" }: { icon: string; value: ReactNode; label: string; color?: string }) {
  return (
    <div className="flex flex-col items-center gap-1 py-3 rounded-2xl bg-[#ffffff08] border border-[var(--line)]">
      <span style={{ color }}><Icon name={icon} size={22} /></span>
      <b className="text-[17px] leading-none">{value}</b>
      <span className="text-[11px] text-[var(--muted)]">{label}</span>
    </div>
  );
}

/* ---------- سربرگ صفحه ---------- */
export function PageHeader({ title, sub, back, right }: { title: ReactNode; sub?: ReactNode; back?: () => void; right?: ReactNode }) {
  return (
    <div className="flex items-center gap-3 px-4 pt-[calc(env(safe-area-inset-top)+10px)] pb-3 sticky top-0 z-30 bg-[var(--bg)]/85 backdrop-blur-xl">
      {back ? <IconBtn icon="back" onClick={back} aria-label="بازگشت" /> : null}
      <div className="flex-1 min-w-0">
        <h1 className="text-[20px] font-black truncate">{title}</h1>
        {sub ? <p className="text-[12px] text-[var(--muted)] truncate">{sub}</p> : null}
      </div>
      {right}
    </div>
  );
}

/* ---------- اسکلت و حالت خالی ---------- */
export function Skeleton({ className = "" }: { className?: string }) { return <div className={`skeleton ${className}`} />; }
export function Empty({ icon = "info", title, sub, action }: { icon?: string; title: string; sub?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center text-center gap-2 py-12 px-6 text-[var(--muted)]">
      <div className="w-16 h-16 rounded-3xl bg-[var(--panel2)] grid place-items-center text-[var(--purple)]"><Icon name={icon} size={30} /></div>
      <b className="text-[var(--text)] text-[16px] mt-1">{title}</b>
      {sub ? <p className="text-[13px] leading-6">{sub}</p> : null}
      {action ? <div className="mt-2">{action}</div> : null}
    </div>
  );
}

/* ---------- برگهٔ پایین (Bottom Sheet) ---------- */
export function Sheet({ open, onClose, title, children }: { open: boolean; onClose: () => void; title?: ReactNode; children: ReactNode }) {
  useEffect(() => { if (!open) return; const h = (e: KeyboardEvent) => e.key === "Escape" && onClose(); window.addEventListener("keydown", h); return () => window.removeEventListener("keydown", h); }, [open, onClose]);
  if (!open) return null;
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center" onClick={onClose}>
      <div className="absolute inset-0 bg-black/60 backdrop-blur-sm anim-fade" />
      <div onClick={(e) => e.stopPropagation()} className="relative w-full max-w-[520px] max-h-[88vh] overflow-y-auto rounded-t-[28px] bg-[var(--panel)] border-t border-[var(--line)] anim-sheet pb-[calc(env(safe-area-inset-bottom)+16px)]">
        <div className="sticky top-0 bg-[var(--panel)] pt-3 pb-2 px-5 z-10">
          <div className="w-12 h-1.5 rounded-full bg-[#ffffff30] mx-auto mb-3" />
          {title ? <div className="flex items-center justify-between"><h3 className="text-[18px] font-black">{title}</h3><IconBtn icon="x" size={34} onClick={onClose} /></div> : null}
        </div>
        <div className="px-5">{children}</div>
      </div>
    </div>
  );
}

/* ---------- Toast ---------- */
type Toast = { id: number; text: string; kind: "ok" | "err" | "info" };
const ToastCtx = createContext<(text: string, kind?: Toast["kind"]) => void>(() => {});
export const useToast = () => useContext(ToastCtx);
export function ToastProvider({ children }: { children: ReactNode }) {
  const [list, setList] = useState<Toast[]>([]);
  const n = useRef(0);
  const push = useCallback((text: string, kind: Toast["kind"] = "info") => {
    const id = ++n.current; setList((l) => [...l, { id, text, kind }]);
    tap(kind === "ok" ? "success" : kind === "err" ? "error" : "light");
    setTimeout(() => setList((l) => l.filter((t) => t.id !== id)), 3200);
  }, []);
  return (
    <ToastCtx.Provider value={push}>
      {children}
      <div className="fixed top-[calc(env(safe-area-inset-top)+12px)] inset-x-0 z-[60] flex flex-col items-center gap-2 pointer-events-none px-4">
        {list.map((t) => (
          <div key={t.id} className={`anim-drop px-4 py-3 rounded-2xl text-[14px] font-bold shadow-2xl border max-w-[420px] w-full text-center ${t.kind === "ok" ? "bg-[#1d3a30] border-[var(--green)] text-[var(--green)]" : t.kind === "err" ? "bg-[#3a1d26] border-[var(--red)] text-[var(--red)]" : "bg-[var(--panel2)] border-[var(--line)] text-[var(--text)]"}`}>{t.text}</div>
        ))}
      </div>
    </ToastCtx.Provider>
  );
}

/* ---------- ورودی ---------- */
export function Input({ label, ...rest }: React.InputHTMLAttributes<HTMLInputElement> & { label?: string }) {
  return (
    <label className="block">
      {label ? <span className="block text-[12px] font-bold text-[var(--muted)] mb-1.5">{label}</span> : null}
      <input {...rest} className={`w-full h-12 px-4 rounded-2xl bg-[#ffffff0a] border border-[var(--line)] focus:border-[var(--purple)] outline-none text-[15px] ${rest.className || ""}`} />
    </label>
  );
}

/* ---------- شمارش معکوس حلقه‌ای ---------- */
export function Ring({ pct, size = 64, stroke = 6, color = "var(--gold)", children }: { pct: number; size?: number; stroke?: number; color?: string; children?: ReactNode }) {
  const r = (size - stroke) / 2, c = 2 * Math.PI * r;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#ffffff18" strokeWidth={stroke} fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={color} strokeWidth={stroke} fill="none" strokeLinecap="round" strokeDasharray={c} strokeDashoffset={c * (1 - Math.max(0, Math.min(1, pct)))} style={{ transition: "stroke-dashoffset .3s linear, stroke .3s" }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center">{children}</div>
    </div>
  );
}

/* ---------- کاغذرنگی جشن ---------- */
export function burst() {
  if (typeof document === "undefined") return;
  const colors = ["#f2ca7c", "#b495f0", "#8dd6b5", "#f499a7", "#8fb7ff"];
  for (let i = 0; i < 36; i++) { const el = document.createElement("i"); el.className = "confetti"; el.style.left = Math.random() * 100 + "vw"; el.style.background = colors[i % colors.length]; el.style.animationDelay = Math.random() * 0.6 + "s"; document.body.appendChild(el); setTimeout(() => el.remove(), 3300); }
}
export function flyEmoji(e: string) {
  if (typeof document === "undefined") return;
  const el = document.createElement("div"); el.className = "emoji-fly"; el.textContent = e; document.body.appendChild(el); setTimeout(() => el.remove(), 1400);
}
