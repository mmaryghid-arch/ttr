"use client";
import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { ensureSession, get, post, isMock, onMock, token, type User, type SiteConfig } from "@/lib/api";

type Ctx = { user: User | null; config: SiteConfig | null; loading: boolean; error: string; mock: boolean; refresh: () => Promise<void>; setUser: (u: User) => void; logout: () => Promise<void> };
const C = createContext<Ctx>({ user: null, config: null, loading: true, error: "", mock: false, refresh: async () => {}, setUser: () => {}, logout: async () => {} });
export const useSession = () => useContext(C);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [config, setConfig] = useState<SiteConfig | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [mock, setMock] = useState(false);
  const busy = useRef(false);

  const refresh = useCallback(async () => {
    if (busy.current) return; busy.current = true;
    try { setError(""); const u = await ensureSession(); setUser(u); get<SiteConfig>("site-config").then(setConfig).catch(() => {}); }
    catch (e) { setError(e instanceof Error ? e.message : "خطای اتصال"); }
    finally { setLoading(false); busy.current = false; }
  }, []);

  useEffect(() => { refresh(); return onMock(() => setMock(true)); }, [refresh]);
  useEffect(() => { setMock(isMock()); }, [user]);
  useEffect(() => {
    // تنظیمات بومی (نوار وضعیت/اسپلش) — در وب بی‌اثر است
    (async () => { try { const { StatusBar, Style } = await import("@capacitor/status-bar"); await StatusBar.setStyle({ style: Style.Dark }); await StatusBar.setBackgroundColor({ color: "#17111f" }); } catch { /* web */ } try { const { SplashScreen } = await import("@capacitor/splash-screen"); await SplashScreen.hide(); } catch { /* web */ } })();
  }, []);
  // به‌روزرسانی سبک هنگام بازگشت به اپ
  useEffect(() => { const h = () => { if (document.visibilityState === "visible" && user) get<User>("me").then(setUser).catch(() => {}); }; document.addEventListener("visibilitychange", h); return () => document.removeEventListener("visibilitychange", h); }, [user]);

  const logout = useCallback(async () => { try { await post("account", { action: "logout" }); } catch { /* ignore */ } token.set(""); setUser(null); setLoading(true); await refresh(); }, [refresh]);

  return <C.Provider value={{ user, config, loading, error, mock, refresh, setUser, logout }}>{children}</C.Provider>;
}
