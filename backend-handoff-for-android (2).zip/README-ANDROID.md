# 📱 اپ اندروید گیمیفای ۲ — راهنمای ساخت و انتشار در پلی‌استور

## مشخصات اپ
| مورد | مقدار |
|---|---|
| **نام پکیج (applicationId)** | `ir.gamifi.bu` |
| نام نمایشی | گیمیفای ۲ |
| نسخه | `1.0.0` (versionCode 1) — در `android/app/build.gradle` |
| minSdk / targetSdk | 24 / 36 |
| بک‌اند | `https://bu.gamifi.ir` (بدون تغییر؛ کاربران، نشست، امتیاز، قبیله، پیام، استوری، لیگ و رویداد مشترک با سایت) |
| فناوری | رابط Next.js (استاتیک، داخل APK) + Capacitor Android (CapacitorHttp، Haptics، StatusBar، SplashScreen) |
| کلید امضا | `release/gamifi-upload.jks` (alias: `gamifi-upload`) — رمز در `release/KEYSTORE-INFO.txt` |

> ⚠️ نام پکیج پس از اولین انتشار در پلی‌استور **قابل تغییر نیست**. اگر نام دیگری می‌خواهید (مثلاً `ir.behinesaz.gamifi`)، قبل از اولین آپلود آن را در `capacitor.config.ts` → `appId` و `android/app/build.gradle` → `namespace`/`applicationId` و `android/app/src/main/res/values/strings.xml` تغییر دهید و `npx cap sync android` بزنید.

## معماری (بدون سرور واسط — مستقیم به bu.gamifi.ir)
```
[APK: رابط کاربری استاتیک داخل اپ]  ── CapacitorHttp (درخواست بومی، بدون CORS) ──▶  https://bu.gamifi.ir/api/*
```
- تمام HTML/JS/CSS داخل APK است (`out/` → `android/app/src/main/assets/public`). **هیچ پوسته‌ای روی سرور لازم نیست.**
- `CapacitorHttp.enabled=true` باعث می‌شود `fetch` از لایهٔ بومی اندروید عبور کند؛ بنابراین نبودِ CORS در بک‌اند مشکلی ایجاد نمی‌کند.
- توکن نشست (`serverToken`) در دستگاه ذخیره و با هدر `x-gamify-token` ارسال می‌شود — همان مکانیزم `src/lib/auth.ts` سرور.
- رویدادهای زنده (SSE) در اپ بومی با polling (۲–۵ ثانیه) جایگزین شده‌اند؛ نبرد زنده و چت با همین روش کار می‌کنند.
- پروژهٔ Next در حالت سرور (پیش‌نمایش) فقط برای توسعه است؛ `/api/gw` و حالت نمایشی **در APK وجود ندارند**.
- قرارداد کامل API و کمبودها: `docs/API-CONTRACT.md`.

## فایل‌های خروجی آماده (پوشهٔ `release/` — و قابل دانلود از پیش‌نمایش در `/release/...`)
| فایل | توضیح |
|---|---|
| `release/gamifi-2-release.apk` | APK امضاشده (نصب مستقیم روی گوشی / تست) |
| `release/gamifi-2-release.aab` | بستهٔ پلی‌استور (Play Console همین را می‌خواهد) |
| `release/gamifi-upload.jks` | **کلید امضا** — نسخهٔ پشتیبان امن بگیرید |
| `release/KEYSTORE-INFO.txt` | رمز، alias و اثر انگشت SHA-1/SHA-256 |

> ⚠️ کلید و رمز آن را فقط خودتان نگه دارید و پس از دانلود، `public/release/` را حذف کنید. هر به‌روزرسانی بعدی باید با **همین کلید** امضا شود.

## ساخت مجدد (روی سیستم خودتان)
نیاز: Node 22، **JDK 21**، Android SDK (platform 36, build-tools 35).
```bash
npm ci
mkdir -p android/keystore && cp gamifi-upload.jks android/keystore/
printf 'storeFile=keystore/gamifi-upload.jks\nstorePassword=<رمز>\nkeyAlias=gamifi-upload\nkeyPassword=<رمز>\n' > android/keystore.properties
echo "sdk.dir=$ANDROID_HOME" > android/local.properties
./android-scripts/build-release.sh      # → release/*.apk و *.aab
```
برای نسخهٔ بعدی، `versionCode`/`versionName` را در `android/app/build.gradle` افزایش دهید.

## انتشار در Play Console
1. حساب توسعه‌دهنده → Create app → «گیمیفای ۲»، فارسی، رایگان، دسته: Trivia/آموزشی.
2. Internal testing → آپلود `gamifi-2-release.aab` (Play App Signing را بپذیرید؛ این کلید به‌عنوان Upload key ثبت می‌شود).
3. فرم‌ها: Privacy policy (صفحه‌ای روی bu.gamifi.ir)، Data safety (نام، ایمیل/موبایل اختیاری، شناسهٔ کاربر؛ رمز هش‌شده با scrypt)، Content rating، Target audience.
4. گرافیک: آیکون ۵۱۲×۵۱۲ (`assets/icon-only.png`)، Feature graphic 1024×500، حداقل ۲ اسکرین‌شات.
5. پس از تست داخلی → Production.

## حساب‌های آزمایشی
- **میهمان:** اپ خودکار با `POST /api/auth/guest` حساب میهمان می‌سازد (دقیقاً مثل سایت).
- **ورود با نام‌کاربری:** از پنل مدیریت سایت (`account → admin-reset`) برای یک کاربر تستی نام‌کاربری/رمز بسازید و در اپ از «پروفایل ← قبلاً حساب داری؟» وارد شوید.

## ساختار کد
```
src/app/page.tsx            خانه: استوری‌ها، جایزهٔ روزانه، دسته‌ها، اعلان مدیر
src/app/play/               انتخاب حالت/دسته → مسابقه (منطق سرور: تایمر، کمک‌ها، امتیاز)
src/app/compete/            لیگ، رویداد، تورنمنت + جدول رتبه‌بندی
src/app/pvp/                نبرد زندهٔ بازیکن‌به‌بازیکن (دعوت/پذیرش/۵ سؤال هم‌زمان/نتیجه)
src/app/tribes/             قبیله‌ها: ساخت، پیوستن، اعضا، چالش
src/app/leaderboard/        تالار افتخار (کل / هفته / قبیله‌ها)
src/app/arena/              مرکز پاداش: چرخ شانس، ماموریت‌ها
src/app/messages/           پیام خصوصی (SSE + polling)
src/app/feed/               فید تجربه‌ها + ساخت پست/استوری
src/app/profile/            پروفایل، دستاوردها، اعلان‌ها، فروشگاه، ارتقای حساب
src/app/login/              ورود با نام‌کاربری/رمز
src/app/api/gw/[...path]/   Gateway (فقط پیش‌نمایش وب؛ در APK نیست)
src/lib/api.ts              کلاینت API + انواع
src/lib/mock-upstream.ts    شبیه‌ساز قرارداد (فقط پیش‌نمایش وب؛ در APK نیست)
capacitor.config.ts         appId=ir.gamifi.bu, webDir=out, CapacitorHttp
android/                    پروژهٔ بومی (Gradle) — آیکون/اسپلش تولیدشده
android-scripts/            ساخت کلید و AAB
docs/API-CONTRACT.md        قرارداد API استخراج‌شده + شکاف‌ها
```
