import type { CapacitorConfig } from "@capacitor/cli";

/**
 * 📱 گیمیفای ۲ — اپ اندروید
 * - رابط کاربری به‌صورت استاتیک داخل APK (webDir=out) قرار می‌گیرد؛ هیچ سروری جز bu.gamifi.ir لازم نیست.
 * - CapacitorHttp: window.fetch را به لایهٔ بومی می‌برد → درخواست مستقیم به https://bu.gamifi.ir/api بدون CORS.
 * - appId = نام پکیج پلی‌استور (پس از انتشار قابل تغییر نیست)
 */
const config: CapacitorConfig = {
  appId: "ir.gamifi.bu",
  appName: "گیمیفای ۲",
  webDir: "out",
  backgroundColor: "#17111f",
  server: { androidScheme: "https", cleartext: false },
  android: { allowMixedContent: false, captureInput: true, webContentsDebuggingEnabled: false },
  plugins: {
    CapacitorHttp: { enabled: true },
    CapacitorCookies: { enabled: true },
    SplashScreen: { launchShowDuration: 1200, launchAutoHide: true, backgroundColor: "#17111f", showSpinner: false, androidScaleType: "CENTER_CROP" },
    StatusBar: { style: "DARK", backgroundColor: "#17111f", overlaysWebView: false },
  },
};

export default config;
