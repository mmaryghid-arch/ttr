import type { NextConfig } from "next";

// APK_BUILD=1 → خروجی استاتیک برای قرارگیری داخل اپ اندروید (بدون سرور)
const apk = process.env.APK_BUILD === "1";
const nextConfig: NextConfig = apk
  ? { output: "export", distDir: "out", trailingSlash: true, images: { unoptimized: true } }
  : {};

export default nextConfig;
