package ir.gamifi.bu;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
